#pragma once

#include "graphicsTypes.h"
#include <type_traits>
#include <utility>

namespace Typhoon {

class Device;

class GPUAllocator final {
public:
	struct Statistics {
		size_t totalMemory;
		size_t totalFreeMemory;
		size_t totalAllocatedMemory;
		size_t allocatedMemoryLastFrame;
		size_t maxAllocatedMemoryInAFrame;
	};

	explicit GPUAllocator(Device& device);
	~GPUAllocator();

	void              createDeviceResources(size_t bufferSize);
	void              freeResources();
	void              beginFrame();
	void              endFrame(int frameIndex);
	void              unmap(const CBAlloc& block);
	CBAlloc           upload(const void* data, size_t size);
	int               getAvailableCount(int desiredCount, size_t elementSize) const;
	void              retireFrame(int frameIndex);
	const Statistics& getStatistics() const;

	// Helpers
	template <class T>
	std::pair<CBAlloc, T*> map(size_t arraySize = 1) {
		void* data = nullptr;
		auto  cb = mapImpl(&data, sizeof(T) * arraySize);
		return { cb, static_cast<T*>(data) };
	}

	template <class T>
	CBAlloc upload(const T& data) {
		static_assert(! std::is_pointer_v<T>);
		return upload(&data, sizeof(data));
	}

private:
	CBAlloc mapImpl(void** data, size_t size);
	CBAlloc allocBlock(size_t size);

private:
	static constexpr size_t maxConstantsPerBlock = 4096;                           // DirectX 11 limit
	static constexpr size_t constantSize = 16;                                     // bytes
	static constexpr size_t maxSizePerBlock = maxConstantsPerBlock * constantSize; // bytes

	struct Segment {
		size_t start;
		size_t size;
	};

	Device&    device;
	GPUBuffer* buffer;
	size_t     bufferSize;
	Segment    freeMemory;
	Segment    freeSegments[2];
	size_t     frameHistory[maxFrameLatency];
	int        beginEndFrameCounter;
	int        mapCounter;
	Statistics stats;
};

} // namespace Typhoon
