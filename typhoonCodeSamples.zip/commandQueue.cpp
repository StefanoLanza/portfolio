#include "commandQueue.h"
#include <core/memoryUtil.h>
#include <graphics/device.h>
#include <graphics/gpuProfiler.h>
#include <graphics/instrumentation.h>
#include <graphics/shader.h>
#if IS_PLATFORM_DX11
#include <graphics/d3d11/deviceDX11.h>
#endif
#include <tracy/Tracy.hpp>

#include <cassert>
#include <vector>

namespace Typhoon {

enum class CommandType : uint8_t {
	beginEvent,
	endEvent,
	setMarker,
	setRenderTargets,
	unbindRenderTargets,
	setUnorderedAccessViews,
	unbindUnorderedAccessViews,
	clearRenderTargetView,
	clearDepthStencilView,
	setBlendState,
	setDepthStencilState,
	setRasterizerState,
	setViewport,
	setScissorRect,
	setShader,
	setPrimitiveTopology,
	setInputLayout,
	setVertexBuffer,
	setIndexBuffer,
	setVSConstantBuffers,
	setVSConstantBuffers1,
	setPSConstantBuffers,
	setPSConstantBuffers1,
	setCSConstantBuffers,
	setCSConstantBuffers1,
	setGSConstantBuffers,
	setGSConstantBuffers1,
	setVSResources,
	setGSResources,
	setPSResources,
	setCSResources,
	setVSSamplers,
	setPSSamplers,
	setCSSamplers,
	setGSSamplers,
	unbindVSResources,
	unbindGSResources,
	unbindPSResources,
	unbindCSResources,
	draw,
	drawInstanced,
	drawIndexed,
	drawIndexedInstanced,
	drawIndexedInstancedIndirect,
	drawFullScreenTriangle,
	dispatch,
	copyResource,
	copySubresourceRegion,
	executeBundle,
};

namespace {
template <class T>
__forceinline void write(void*& memory, const T& prm) {
	std::memcpy(memory, &prm, sizeof prm);
	memory = advancePointer(memory, sizeof prm);
}

template <class T>
__forceinline void writeArray(void*& memory, const T* prm, size_t count) {
	std::memcpy(memory, prm, (sizeof prm[0]) * count);
	memory = advancePointer(memory, (sizeof prm[0]) * count);
}

__forceinline void writeNullptr(void*& memory, size_t count) {
	std::memset(memory, 0, sizeof(nullptr) * count);
	memory = advancePointer(memory, sizeof(nullptr) * count);
}

template <class T>
__forceinline void read(const void*& memory, T& prm) {
	std::memcpy(&prm, memory, sizeof prm);
	memory = advancePointer(memory, sizeof prm);
}

template <class T>
__forceinline const T* readArray(const void*& memory, size_t count) {
	const T* array = static_cast<const T*>(memory);
	memory = advancePointer(memory, sizeof(T) * count);
	return array;
}

void runCommands(const Command* cmd, Device& device, GPUProfiler& profiler);
void writeSRVs(void* memory, uint startSlot, uint numViews, ShaderResourceView* const views[]);
#if IS_PLATFORM_DX11
void runCommand(CommandType cmdType, const void* cmdData, ID3D11DeviceContext1* context, DeviceState& deviceState, Device& device,
                GPUProfiler& profiler);
#endif
} // namespace

CommandAllocator::CommandAllocator(Allocator& baseAllocator, CommandBufferFamily family)
    : baseAllocator(baseAllocator)
    , poolAllocator(baseAllocator, 65536)
    , commandAllocator(baseAllocator)
    , family(family) {
}

// TODO Support permanent command buffers
// atm all allocations are reset in ::reset()
CommandBuffer* CommandAllocator::newCommandBuffer() {
	return poolAllocator.make(commandAllocator, family);
}

void CommandAllocator::reset() {
	commandAllocator.rewind();
}

CommandQueue::CommandQueue(Device& device)
    : device{device} {
}

void CommandQueue::executeCommandBuffers(size_t count, const CommandBuffer* const commandBuffers[], GPUProfiler& profiler) {
	ZoneScoped;
	Device& device = this->device;
	for (size_t i = 0; i < count; ++i) {
		// FIXME assert(commandBuffers[i]->family == this->family);
#ifdef _DEBUG
		const_cast<CommandBuffer*>(commandBuffers[i])->canReset = true;
		if (commandBuffers[i]->family != CommandBufferFamily::bundle) {
			assert(commandBuffers[i]->queueCount == 0);
		}
		++const_cast<CommandBuffer*>(commandBuffers[i])->queueCount;
#endif
		runCommands(commandBuffers[i]->root, device, profiler);
	}
}

namespace {

void runCommands(const Command* cmd, Device& device, GPUProfiler& profiler) {
#if IS_PLATFORM_DX11
	D3D11Device&          d3d11Device = reinterpret_cast<D3D11Device&>(device);
	ID3D11DeviceContext1* d3d11Context = d3d11Device.getImmediateContext();
	DeviceState&          deviceState = d3d11Device.getState();
#endif

	do {
#if IS_PLATFORM_DX11
		runCommand(cmd->type, cmd->memoryOffset, d3d11Context, deviceState, device, profiler);
#endif
		cmd = cmd->next;
	} while (cmd);
}

void writeSRVs(void* memory, uint startSlot, uint numViews, ShaderResourceView* const views[]) {
	write(memory, startSlot);
	write(memory, numViews);
	writeArray(memory, views, numViews);
}

void writeSamplers(void* memory, uint startSlot, uint numSamplers, SamplerState const samplers[]) {
	write(memory, startSlot);
	write(memory, numSamplers);
	writeArray(memory, samplers, numSamplers);
}

} // namespace

CommandBuffer::CommandBuffer(LinearAllocator& allocator, [[maybe_unused]] CommandBufferFamily family)
    : allocator { &allocator }
    , root { nullptr }
    , tail { nullptr }
    , flags { CommandBufferFlags::open }
#ifdef _DEBUG
    , family { family }
    , queueCount { 0 }
    , canReset { true }
#endif
{
}

const Command* CommandBuffer::getRoot() const {
	return root;
}

void CommandBuffer::beginEvent(const char* eventName) {
	const size_t l = strlen(eventName) + 1; // with null terminator
	const size_t dataSize = sizeof(size_t) + l;
	void*        memory = allocCommand(CommandType::beginEvent, dataSize);
	write(memory, l);
	std::memcpy(memory, eventName, l);
}

void CommandBuffer::beginEventAtFront(const char* eventName) {
	const size_t l = strlen(eventName) + 1; // with null terminator
	const size_t dataSize = sizeof(size_t) + l;
	void*        memory = allocCommandAtFront(CommandType::beginEvent, dataSize);
	write(memory, l);
	std::memcpy(memory, eventName, l);
}

void CommandBuffer::endEvent() {
	allocCommand(CommandType::endEvent, 0);
}

void CommandBuffer::setMarker(const char* marker) {
	const size_t l = strlen(marker) + 1; // with null terminator
	const size_t dataSize = sizeof(size_t) + l;
	void*        memory = allocCommandAtFront(CommandType::setMarker, dataSize);
	write(memory, l);
	std::memcpy(memory, marker, l);
}

void CommandBuffer::setRenderTargets(uint numViews, RenderTargetView* const renderTargetViews[], DepthStencilView* depthStencilView) {
	assert(this->family == CommandBufferFamily::direct);
	assert(numViews == 0 || renderTargetViews);
	const size_t dataSize = sizeof numViews + sizeof(RenderTargetView*) * numViews + sizeof depthStencilView;
	void*        memory = allocCommand(CommandType::setRenderTargets, dataSize);
	write(memory, numViews);
	writeArray(memory, renderTargetViews, numViews);
	write(memory, depthStencilView);
}

void CommandBuffer::setRenderTargets(span<RenderTargetView* const> renderTargetViews, DepthStencilView* depthStencilView) {
	assert(this->family == CommandBufferFamily::direct);
	assert(renderTargetViews.data());
	setRenderTargets(static_cast<uint>(renderTargetViews.size()), renderTargetViews.data(), depthStencilView);
}

void CommandBuffer::unbindRenderTargets() {
	assert(this->family == CommandBufferFamily::direct);
	allocCommand(CommandType::unbindRenderTargets, 0);
}

void CommandBuffer::clearRenderTargetView(RenderTargetView* rtv, float r, float g, float b, float a) {
	assert(this->family == CommandBufferFamily::direct);
	assert(rtv);
	constexpr size_t dataSize = sizeof rtv + sizeof(float[4]);
	void*            memory = allocCommand(CommandType::clearRenderTargetView, dataSize);
	const float      rgba[4] = { r, g, b, a };
	write(memory, rtv);
	write(memory, rgba);
}

void CommandBuffer::clearDepthStencilView(DepthStencilView* dsv, Clear clearFlags, float depth, uint8_t stencil) {
	assert(this->family == CommandBufferFamily::direct);
	assert(dsv);
	constexpr size_t dataSize = sizeof dsv + sizeof clearFlags + sizeof depth + sizeof stencil;
	void*            memory = allocCommand(CommandType::clearDepthStencilView, dataSize);
	write(memory, dsv);
	write(memory, clearFlags);
	write(memory, depth);
	write(memory, stencil);
}

void CommandBuffer::setUnorderedAccessViews(uint startSlot, span<UnorderedAccessView* const> uavs) {
	assert(this->family == CommandBufferFamily::compute);
	assert(! uavs.empty());
	const uint   numUAVs = static_cast<uint>(uavs.size());
	const size_t dataSize = sizeof startSlot + sizeof numUAVs + sizeof(UnorderedAccessView*) * numUAVs;
	void*        memory = allocCommand(CommandType::setUnorderedAccessViews, dataSize);
	write(memory, startSlot);
	write(memory, numUAVs);
	writeArray(memory, uavs.data(), numUAVs);
}

void CommandBuffer::unbindUnorderedAccessViews() {
	assert(this->family == CommandBufferFamily::compute);
	allocCommand(CommandType::unbindUnorderedAccessViews, 0);
}

void CommandBuffer::setViewport(const ViewportI& viewport) {
	assert(this->family == CommandBufferFamily::direct);
	void* memory = allocCommand(CommandType::setViewport, sizeof viewport);
	write(memory, viewport);
}

void CommandBuffer::setShader(const Shader* shader) {
	assert(shader);
	void* memory = allocCommand(CommandType::setShader, sizeof shader);
	write(memory, shader);
}

void CommandBuffer::setInputLayout(InputLayout* inputLayout) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	void* memory = allocCommand(CommandType::setInputLayout, sizeof inputLayout);
	write(memory, inputLayout);
}

void CommandBuffer::setIndexBuffer(GPUBuffer* buffer, IndexFormat indexType, uint offset) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	constexpr size_t dataSize = sizeof buffer + sizeof indexType + sizeof offset;
	void*            memory = allocCommand(CommandType::setIndexBuffer, dataSize);
	write(memory, buffer);
	write(memory, indexType);
	write(memory, offset);
}

void CommandBuffer::setVertexBuffer(GPUBuffer* buffer, uint stride, uint startSlot, uint offset) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	assert(buffer);
	const uint       numBuffers = 1;
	constexpr size_t dataSize = sizeof startSlot + sizeof numBuffers + sizeof buffer + sizeof stride + sizeof offset;
	void*            memory = allocCommand(CommandType::setVertexBuffer, dataSize);
	write(memory, startSlot);
	write(memory, numBuffers);
	write(memory, buffer);
	write(memory, stride);
	write(memory, offset);
}

void CommandBuffer::setVertexBuffers(uint startSlot, uint numBuffers, GPUBuffer* const vertexBuffers[], const uint strides[],
                                     const uint offsets[]) {
	const size_t dataSize =
	    sizeof startSlot + sizeof numBuffers + sizeof vertexBuffers[0] * numBuffers + sizeof strides[0] * numBuffers + sizeof offsets[0] * numBuffers;
	void* memory = allocCommand(CommandType::setVertexBuffer, dataSize);
	write(memory, startSlot);
	write(memory, numBuffers);
	writeArray(memory, vertexBuffers, numBuffers);
	writeArray(memory, strides, numBuffers);
	writeArray(memory, offsets, numBuffers);
}

void CommandBuffer::setPrimitiveTopology(PrimitiveType primitiveType) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	void* memory = allocCommand(CommandType::setPrimitiveTopology, sizeof primitiveType);
	write(memory, primitiveType);
}

void CommandBuffer::setBlendState(BlendState state) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	assert(state);
	void* memory = allocCommand(CommandType::setBlendState, sizeof state);
	write(memory, state);
}

void CommandBuffer::setDepthStencilState(DepthStencilState state, uint stencilRef) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	assert(state);
	const size_t size = sizeof state + sizeof stencilRef;
	void*        memory = allocCommand(CommandType::setDepthStencilState, size);
	write(memory, state);
	write(memory, stencilRef);
}

void CommandBuffer::setRasterizerState(RasterizerState state) {
	assert(state);
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	void* memory = allocCommand(CommandType::setRasterizerState, sizeof state);
	write(memory, state);
}

void CommandBuffer::setScissorRect(const TextureRect& scissorRect) {
	void* memory = allocCommand(CommandType::setScissorRect, sizeof scissorRect);
	write(memory, scissorRect);
}

void CommandBuffer::setVSConstantBuffers(uint startSlot, span<const CBAlloc> cbs) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	writeConstantBuffers(startSlot, cbs, CommandType::setVSConstantBuffers1);
}

void CommandBuffer::setVSRawConstantBuffers(uint startSlot, span<GPUBuffer* const> cbs) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	uint         numBuffers = static_cast<uint>(cbs.size());
	const size_t dataSize = sizeof startSlot + sizeof numBuffers + sizeof(cbs[0]) * numBuffers;
	void*        memory = allocCommand(CommandType::setVSConstantBuffers, dataSize);
	write(memory, startSlot);
	write(memory, numBuffers);
	writeArray(memory, cbs.data(), cbs.size());
}

void CommandBuffer::setPSConstantBuffers(uint startSlot, span<const CBAlloc> cbs) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	writeConstantBuffers(startSlot, cbs, CommandType::setPSConstantBuffers1);
}

void CommandBuffer::setPSRawConstantBuffers(uint startSlot, span<GPUBuffer* const> cbs) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	uint         numBuffers = static_cast<uint>(cbs.size());
	const size_t dataSize = sizeof startSlot + sizeof numBuffers + sizeof(cbs[0]) * numBuffers;
	void*        memory = allocCommand(CommandType::setPSConstantBuffers, dataSize);
	write(memory, startSlot);
	write(memory, numBuffers);
	writeArray(memory, cbs.data(), cbs.size());
}

void CommandBuffer::setGSConstantBuffers(uint startSlot, span<const CBAlloc> cbs) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	writeConstantBuffers(startSlot, cbs, CommandType::setGSConstantBuffers1);
}

void CommandBuffer::setGSResources(uint startSlot, span<ShaderResourceView* const> views) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	assert(startSlot + views.size() <= D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT);
	const uint32_t numViews = static_cast<uint32_t>(views.size());
	const size_t   dataSize = sizeof startSlot + sizeof numViews + sizeof(views[0]) * views.size();
	void*          memory = allocCommand(CommandType::setGSResources, dataSize);
	writeSRVs(memory, startSlot, numViews, views.data());
}

void CommandBuffer::setCSConstantBuffers(uint startSlot, span<const CBAlloc> cbs) {
	assert(this->family == CommandBufferFamily::compute);
	writeConstantBuffers(startSlot, cbs, CommandType::setCSConstantBuffers1);
}

void CommandBuffer::setVSSamplers(uint startSlot, span<SamplerState const> samplers) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	uint         numSamplers = static_cast<uint>(samplers.size());
	const size_t dataSize = sizeof startSlot + sizeof numSamplers + sizeof(samplers[0]) * numSamplers;
	void*        memory = allocCommand(CommandType::setVSSamplers, dataSize);
	writeSamplers(memory, startSlot, numSamplers, samplers.data());
}

void CommandBuffer ::setPSResources(uint startSlot, span<ShaderResourceView* const> views) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	assert(startSlot + views.size() <= D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT);
	const uint   numViews = static_cast<uint>(views.size());
	const size_t dataSize = sizeof startSlot + sizeof numViews + sizeof(views[0]) * numViews;
	void*        memory = allocCommand(CommandType::setPSResources, dataSize);
	writeSRVs(memory, startSlot, numViews, views.data());
}

void CommandBuffer::setPSSamplers(uint startSlot, span<SamplerState const> samplers) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	uint         numSamplers = static_cast<uint>(samplers.size());
	const size_t dataSize = sizeof startSlot + sizeof numSamplers + sizeof(samplers[0]) * numSamplers;
	void*        memory = allocCommand(CommandType::setPSSamplers, dataSize);
	writeSamplers(memory, startSlot, numSamplers, samplers.data());
}

void CommandBuffer::setCSSamplers(uint startSlot, span<SamplerState const> samplers) {
	assert(this->family == CommandBufferFamily::compute);
	uint         numSamplers = static_cast<uint>(samplers.size());
	const size_t dataSize = sizeof startSlot + sizeof numSamplers + sizeof(samplers[0]) * numSamplers;
	void*        memory = allocCommand(CommandType::setCSSamplers, dataSize);
	writeSamplers(memory, startSlot, numSamplers, samplers.data());
}

void CommandBuffer::setGSSamplers(uint startSlot, span<SamplerState const> samplers) {
	assert(this->family == CommandBufferFamily::compute);
	uint         numSamplers = static_cast<uint>(samplers.size());
	const size_t dataSize = sizeof startSlot + sizeof numSamplers + sizeof(samplers[0]) * numSamplers;
	void*        memory = allocCommand(CommandType::setGSSamplers, dataSize);
	writeSamplers(memory, startSlot, numSamplers, samplers.data());
}

void CommandBuffer::unbindVSResources() {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	allocCommand(CommandType::unbindVSResources, 0);
}

void CommandBuffer::unbindGSResources() {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	allocCommand(CommandType::unbindGSResources, 0);
}

void CommandBuffer::unbindPSResources() {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	allocCommand(CommandType::unbindPSResources, 0);
}

void CommandBuffer::unbindCSResources() {
	assert(this->family == CommandBufferFamily::compute);
	allocCommand(CommandType::unbindCSResources, 0);
}

void CommandBuffer::setCSResources(uint startSlot, span<ShaderResourceView* const> views) {
	assert(this->family == CommandBufferFamily::compute);
	assert(startSlot + views.size() <= D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT);
	const uint   numViews = static_cast<uint>(views.size());
	const size_t dataSize = sizeof startSlot + sizeof numViews + sizeof(views[0]) * numViews;
	void*        memory = allocCommand(CommandType::setCSResources, dataSize);
	writeSRVs(memory, startSlot, numViews, views.data());
}

void CommandBuffer::draw(uint vertexCount, uint startVertexLocation) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	constexpr size_t dataSize = sizeof vertexCount + sizeof startVertexLocation;
	void*            memory = allocCommand(CommandType::draw, dataSize);
	write(memory, vertexCount);
	write(memory, startVertexLocation);
}

void CommandBuffer::drawInstanced(uint vertexCountPerInstance, uint instanceCount, uint startVertexLocation, uint startInstanceLocation) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	constexpr size_t dataSize = sizeof vertexCountPerInstance + sizeof instanceCount + sizeof startVertexLocation + sizeof startInstanceLocation;
	void*            memory = allocCommand(CommandType::drawInstanced, dataSize);
	write(memory, vertexCountPerInstance);
	write(memory, instanceCount);
	write(memory, startVertexLocation);
	write(memory, startInstanceLocation);
}

void CommandBuffer::drawIndexed(uint indexCount, uint startIndexLocation, int baseVertexLocation) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	constexpr size_t dataSize = sizeof indexCount + sizeof startIndexLocation + sizeof baseVertexLocation;
	void*            memory = allocCommand(CommandType::drawIndexed, dataSize);
	write(memory, indexCount);
	write(memory, startIndexLocation);
	write(memory, baseVertexLocation);
}

void CommandBuffer::drawIndexedInstanced(uint indexCountPerInstance, uint instanceCount, uint startIndexLocation, int baseVertexLocation,
                                         uint startInstanceLocation) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	constexpr size_t dataSize =
	    sizeof indexCountPerInstance + sizeof instanceCount + sizeof startIndexLocation + sizeof baseVertexLocation + sizeof startInstanceLocation;
	void* memory = allocCommand(CommandType::drawIndexedInstanced, dataSize);
	write(memory, indexCountPerInstance);
	write(memory, instanceCount);
	write(memory, startIndexLocation);
	write(memory, baseVertexLocation);
	write(memory, startInstanceLocation);
}

void CommandBuffer::drawIndexedInstancedIndirect(GPUBuffer* bufferForArgs, uint alignedByteOffsetForArgs) {
	assert(this->family == CommandBufferFamily::direct || this->family == CommandBufferFamily::bundle);
	assert(bufferForArgs);
	constexpr size_t dataSize =
	    sizeof bufferForArgs + sizeof alignedByteOffsetForArgs;
	void* memory = allocCommand(CommandType::drawIndexedInstancedIndirect, dataSize);
	write(memory, bufferForArgs);
	write(memory, alignedByteOffsetForArgs);
}

void CommandBuffer::dispatch(uint threadGroupCountX, uint threadGroupCountY, uint threadGroupCountZ) {
	assert(this->family == CommandBufferFamily::compute);
	const size_t dataSize = sizeof threadGroupCountX + sizeof threadGroupCountY + sizeof threadGroupCountZ;
	void*        memory = allocCommand(CommandType::dispatch, dataSize);
	write(memory, threadGroupCountX);
	write(memory, threadGroupCountY);
	write(memory, threadGroupCountZ);
}

void CommandBuffer::copyResource(Resource* dst, Resource* src) {
	assert(this->family == CommandBufferFamily::copy);
	constexpr size_t cmdDataSize = sizeof dst + sizeof src;
	void*            memory = allocCommand(CommandType::copyResource, cmdDataSize);
	write(memory, dst);
	write(memory, src);
}

void CommandBuffer::copySubresourceRegion(Resource* dst, uint dstArraySlice, uint dstMipSlice, uint dstX, uint dstY, Resource* src,
                                          uint srcArraySlice, uint srcMipSlice, uint srcX, uint srcY, uint srcW, uint srcH) {
	assert(dst);
	assert(src);
	assert(this->family == CommandBufferFamily::copy);
	constexpr uint   srcZ = 0;
	constexpr uint   srcD = 1;
	constexpr uint   dstZ = 0;
	constexpr size_t cmdDataSize = sizeof dst + sizeof dstArraySlice + sizeof dstMipSlice + sizeof dstX + sizeof dstY + sizeof dstZ + sizeof src +
	                               sizeof srcArraySlice + sizeof srcMipSlice + sizeof srcX + sizeof srcY + sizeof srcZ + sizeof srcW + sizeof srcH +
	                               sizeof srcD;
	void* memory = allocCommand(CommandType::copySubresourceRegion, cmdDataSize);
	write(memory, dst);
	write(memory, dstArraySlice);
	write(memory, dstMipSlice);
	write(memory, dstX);
	write(memory, dstY);
	write(memory, dstZ);
	write(memory, src);
	write(memory, srcArraySlice);
	write(memory, srcMipSlice);
	write(memory, srcX);
	write(memory, srcY);
	write(memory, srcZ);
	write(memory, srcW);
	write(memory, srcH);
	write(memory, srcD);
}

void CommandBuffer::copySubresourceRegion3D(Resource* dst, uint dstMipSlice, uint dstX, uint dstY, uint dstZ, Resource* src, uint srcMipSlice,
                                            uint srcX, uint srcY, uint srcZ, uint srcW, uint srcH, uint srcD) {
	assert(this->family == CommandBufferFamily::copy);
	constexpr uint   dstArraySlice = 0;
	constexpr uint   srcArraySlice = 0;
	constexpr size_t cmdDataSize = sizeof dst + sizeof dstArraySlice + sizeof dstMipSlice + sizeof dstX + sizeof dstY + sizeof dstZ + sizeof src +
	                               sizeof srcArraySlice + sizeof srcMipSlice + sizeof srcX + sizeof srcY + sizeof srcZ + sizeof srcW + sizeof srcH +
	                               sizeof srcD;
	void* memory = allocCommand(CommandType::copySubresourceRegion, cmdDataSize);
	write(memory, dst);
	write(memory, dstArraySlice);
	write(memory, dstMipSlice);
	write(memory, dstX);
	write(memory, dstY);
	write(memory, dstZ);
	write(memory, src);
	write(memory, srcArraySlice);
	write(memory, srcMipSlice);
	write(memory, srcX);
	write(memory, srcY);
	write(memory, srcZ);
	write(memory, srcW);
	write(memory, srcH);
	write(memory, srcD);
}

void CommandBuffer::setVSResources(uint startSlot, span<ShaderResourceView* const> views) {
	assert(startSlot + views.size() <= D3D11_COMMONSHADER_INPUT_RESOURCE_SLOT_COUNT);
	const uint   numViews = static_cast<uint>(views.size());
	const size_t dataSize = sizeof startSlot + sizeof numViews + sizeof(views[0]) * numViews;
	void*        memory = allocCommand(CommandType::setVSResources, dataSize);
	writeSRVs(memory, startSlot, numViews, views.data());
}

void CommandBuffer::executeBundle(CommandBuffer* bundle) {
	assert(this->family == CommandBufferFamily::direct);
	assert(bundle->family == CommandBufferFamily::bundle);
	void* memory = allocCommand(CommandType::executeBundle, sizeof bundle);
	write(memory, bundle);
}

void CommandBuffer::reset() {
	assert(canReset);
	// FIXME Assert that it's been submitted
	this->flags |= CommandBufferFlags::open;
	this->root = nullptr;
	this->tail = nullptr;
#ifdef _DEBUG
	this->queueCount = 0;
#endif
}

void CommandBuffer::close() {
	this->flags &= ~CommandBufferFlags::open;
}

void CommandBuffer::drawFullScreenTriangle() {
	allocCommand(CommandType::drawFullScreenTriangle, 0);
}

void* CommandBuffer::allocCommand(CommandType type, size_t dataSize) {
	void* memory = allocator->alloc(sizeof(Command) + dataSize, Allocator::defaultAlignment);
	assert(memory);
	auto cmd = static_cast<Command*>(memory);
	cmd->type = type;
	cmd->memoryOffset = advancePointer(memory, sizeof(Command));
	cmd->next = nullptr;
	if (! root) {
		root = cmd;
	}
	if (tail) {
		tail->next = cmd;
	}
	tail = cmd;
	return cmd->memoryOffset;
}

void* CommandBuffer::allocCommandAtFront(CommandType type, size_t dataSize) {
	void* memory = allocator->alloc(sizeof(Command) + dataSize, Allocator::defaultAlignment);
	assert(memory);
	auto cmd = static_cast<Command*>(memory);
	cmd->type = type;
	cmd->memoryOffset = advancePointer(memory, sizeof(Command));
	cmd->next = root;
	root = cmd;
	if (! tail) {
		tail = cmd;
	}
	return cmd->memoryOffset;
}

void CommandBuffer::writeConstantBuffers(uint startSlot, span<const CBAlloc> cbs, CommandType commandType) {
	const uint cbCount = static_cast<uint>(cbs.size());
	assert(cbCount > 0);
	const size_t dataSize = sizeof startSlot + sizeof cbCount + sizeof(CBAlloc) * cbCount;
	void*        memory = allocCommand(commandType, dataSize);

	write(memory, startSlot);
	write(memory, cbCount);

	constexpr size_t tmpSize = 16;
	GPUBuffer*       buffer[tmpSize];
	uint             firstConstant[tmpSize];
	uint             numConstants[tmpSize];
	assert(cbCount <= tmpSize);
	for (uint i = 0; i < cbCount; ++i) {
		buffer[i] = cbs[i].buffer;
		firstConstant[i] = cbs[i].firstConstant;
		numConstants[i] = cbs[i].numConstants;
	}
	writeArray(memory, buffer, cbCount);
	writeArray(memory, firstConstant, cbCount);
	writeArray(memory, numConstants, cbCount);
}

} // namespace Typhoon

#if IS_PLATFORM_DX11
#include "d3d11/commandQueue_dx11.inl"
#endif
