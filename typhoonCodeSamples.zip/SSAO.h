#pragma once

#include <graphics/renderNode.h>

namespace Typhoon {

class SSAOSettings final {
public:
	void  setEnabled(bool value);
	bool  getEnabled() const;
	void  setRadius(float value);
	float getRadius() const;
	void  setIntensity(float value);
	float getIntensity() const;
	void  setMaxDepth(float value);
	float getMaxDepth() const;
	void  setBias(float value);
	float getBias() const;
	void  setDepthMipOffset(float value);
	float getDepthMipOffset() const;
	void  setBilateralStrength(float value);
	float getBilateralStrength() const;

private:
	bool  enabled = true;
	float radius = 1.0f; // world (view) space size of the occlusion sphere.
	float intensity = 0.9f;
	float maxDepth = 200.f; // meters
	float bias = 0.1f;
	float depthMipOffset = 0.f;
	float bilateralStrength = 16.f;
};

struct SSAOSamplingPass {
	ShaderPtr           shader;
	PassId              passId;
	Texture*            hilbertTexture = nullptr;
	ShaderResourceView* hilbertSRV = nullptr;
};

struct SSAOFilterPass {
	ShaderPtr shader;
	bool      isHorizontalPass = false;
};

class SSAORenderNode final : public RenderNode {
public:
	RenderSettings getSettings() override;
	void           initializeShaders(const ShaderManager& shaderManager) override;
	void           declareResources(PipelineSetup& pipelineSetup) override;
	void           setupPipeline(PipelineSetup& pipelineSetup) override;
	void           onDeviceCreated(Device& device) override;

private:
	void storePrevious(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const;
	void sample(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const;
	void filter(SSAOFilterPass& filterPass, const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline,
	            Device& device) const;

private:
	SSAOSettings      settings;
	DepthStencilState depthStencilState;
	SSAOSamplingPass  samplingPass;
	SSAOFilterPass    hrzFilterPass;
	SSAOFilterPass    vrtFilterPass;
};

} // namespace Typhoon
