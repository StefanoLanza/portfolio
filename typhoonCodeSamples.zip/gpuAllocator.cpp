#include "gpuAllocator.h"
#include "device.h"
#include <tracy/Tracy.hpp>

#include <algorithm>
#include <cassert>

#define LOGGING_ENABLED 0

namespace Typhoon {

GPUAllocator::GPUAllocator(Device& device)
    : device(device)
    , buffer { nullptr }
    , bufferSize { 0 }
    , freeMemory {}
    , freeSegments {}
    , frameHistory {}
    , beginEndFrameCounter(0)
    , mapCounter(0)
    , stats {} {
}

GPUAllocator::~GPUAllocator() = default;

void GPUAllocator::createDeviceResources(size_t bufferSize) {
	assert(bufferSize % 256 == 0);
	assert(bufferSize >= maxSizePerBlock);
	assert(bufferSize % maxSizePerBlock == 0);

	buffer = device.createConstantBuffer(static_cast<uint>(bufferSize));
	freeMemory.start = 0;
	freeMemory.size = bufferSize;

	stats.totalMemory = bufferSize;
	stats.totalFreeMemory = bufferSize;
	stats.totalAllocatedMemory = 0;
	stats.maxAllocatedMemoryInAFrame = 0;

	this->bufferSize = bufferSize;
}

void GPUAllocator::freeResources() {
	if (buffer) {
		device.releaseResource(buffer);
		buffer = nullptr;
	}

	stats.totalMemory = 0;
	stats.totalAllocatedMemory = 0;
	stats.totalFreeMemory = 0;
}

void GPUAllocator::beginFrame() {
	assert(beginEndFrameCounter == 0);
	beginEndFrameCounter = 1;

	// Initialize free segments
	if (freeMemory.start + freeMemory.size <= bufferSize) {
		// Free memory is contiguous
		freeSegments[0] = freeMemory;
		freeSegments[1].start = 0;
		freeSegments[1].size = 0;
	}
	else {
		// Split free memory in two segments
		freeSegments[0].start = freeMemory.start;
		freeSegments[0].size = bufferSize - freeMemory.start;
		freeSegments[1].start = 0;
		freeSegments[1].size = freeMemory.size - (bufferSize - freeMemory.start);
		assert(freeSegments[0].size > 0);
		assert(freeSegments[1].size > 0);
	}

	stats.allocatedMemoryLastFrame = 0;
}

void GPUAllocator::endFrame(int frameIndex) {
	assert(beginEndFrameCounter == 1);
	assert(frameIndex >= 0 && frameIndex < maxFrameLatency);

	beginEndFrameCounter = 0;

	stats.allocatedMemoryLastFrame = 0;

	size_t reclaimedSize = 0;
	if (freeSegments[1].start == 0) {
		// Either memory was contiguous or the second segment was not allocated
		// TODO Handle separately the two cases for clarity ?
		reclaimedSize = freeSegments[0].start - freeMemory.start;
		freeMemory.start = freeSegments[0].start % bufferSize; // handle wrap
		freeMemory.size = freeSegments[0].size + freeSegments[1].size;
	}
	else {
		assert(freeSegments[1].start < bufferSize);
		// Free memory is not contiguous and the second segment has been allocated
		reclaimedSize = (bufferSize - freeMemory.start) /*reclaim whole first segment*/ + freeSegments[1].start;
		freeMemory = freeSegments[1];
	}
	assert(reclaimedSize >= 0 && reclaimedSize <= bufferSize);
	// Update statistics
	stats.totalAllocatedMemory += reclaimedSize;
	stats.totalFreeMemory -= reclaimedSize;
	stats.allocatedMemoryLastFrame += reclaimedSize;
	assert(stats.totalFreeMemory >= 0);
	assert(stats.totalAllocatedMemory + stats.totalFreeMemory == stats.totalMemory);
	// Update frame history
	frameHistory[frameIndex] = reclaimedSize;

	stats.maxAllocatedMemoryInAFrame = std::max(stats.maxAllocatedMemoryInAFrame, stats.allocatedMemoryLastFrame);
}

CBAlloc GPUAllocator::upload(const void* data, size_t size) {
	ZoneScoped;

	// Require alignment of data to 16 bytes
	assert(reinterpret_cast<uintptr_t>(data) % constantSize == 0);
	assert(size > 0 && size <= bufferSize);

	void*   mappedData = nullptr;
	CBAlloc block = mapImpl(&mappedData, size);
	if (block.buffer) {
		std::memcpy(mappedData, data, size);
		unmap(block);
	}
	return block;
}

CBAlloc GPUAllocator::mapImpl(void** outData, size_t size) {
	ZoneScoped;

	assert(mapCounter == 0);
	assert(size > 0);
	assert(outData);

	// Align size to 256
	const size_t alignedSize = (size + 255u) & ~(255u);

	if (alignedSize > maxSizePerBlock) {
#if LOGGING_ENABLED
		LogError("Map failed. Allocation size ({} bytes) exceeds max size per block ({})", alignedSize, maxSizePerBlock);
#endif
		return {};
	}

	void*   mappedData = nullptr;
	CBAlloc block = allocBlock(alignedSize);
	if (block.buffer) {
		// Allocation succeeded
		void* const volatile mappedMemory = device.map(buffer, MapType::writeNoOverwrite);
		assert(mappedMemory);
		if (mappedMemory) {
			mappedData = static_cast<char*>(mappedMemory) + block.firstConstant * constantSize;
			mapCounter = 1; // must call Unmap
		}
		else {
			// Map failed
			block.buffer = nullptr; // still allow binding. Shaders will fetch zeros
		}
	}

#if LOGGING_ENABLED
	if (data == nullptr) {
		LogError("Failed allocation of {} bytes", alignedSize);
	}
#endif
	assert(mappedData);
	*outData = mappedData;
	return block;
}

void GPUAllocator::unmap(const CBAlloc& block) {
	ZoneScoped;
	assert(mapCounter == 1);
	mapCounter = 0;
	assert(block.buffer);
	device.unmap(block.buffer);
}

int GPUAllocator::getAvailableCount(int desiredCount, size_t elementSize) const {
	assert(desiredCount > 0);
	assert(elementSize > 0);
	assert(elementSize % constantSize == 0);

	for (int s = 0; s < 2; ++s) {
		assert(freeSegments[s].size % 256 == 0);
		size_t availableCount = (freeSegments[s].size / elementSize);
		if (availableCount > 0) {
			availableCount = std::min(availableCount, (size_t)desiredCount);
			availableCount = std::min(availableCount, maxSizePerBlock / elementSize);
			return static_cast<int>(availableCount);
		}
	}
	return 0; // no available space in buffer
}

const GPUAllocator::Statistics& GPUAllocator::getStatistics() const {
	return stats;
}

void GPUAllocator::retireFrame(int frameIndex) {
	assert(frameIndex >= 0 && frameIndex < maxFrameLatency);
	const size_t retiredSize = frameHistory[frameIndex];
	assert(retiredSize >= 0);
	freeMemory.size += retiredSize;
	assert(freeMemory.size <= bufferSize);
	if (freeMemory.size == bufferSize) {
		// Reset offset
		freeMemory.start = 0;
	}
	stats.totalFreeMemory += retiredSize;
	stats.totalAllocatedMemory -= retiredSize;
	assert(stats.totalAllocatedMemory >= 0);
}

CBAlloc GPUAllocator::allocBlock(size_t size) {
	CBAlloc block {
		.buffer = nullptr,
		.firstConstant = 0,
		.numConstants = 0,
	};

	for (int s = 0; s < 2; ++s) {
		if (size <= freeSegments[s].size) {
			// Buffer segment has available free space
			assert(freeSegments[s].start % constantSize == 0);
			block.buffer = buffer;
			block.firstConstant = static_cast<uint>(freeSegments[s].start / constantSize);
			block.numConstants = static_cast<uint>(size / constantSize);
			freeSegments[s].start += size;
			freeSegments[s].size -= size;
			break;
		}
	}
	return block;
}

} // namespace Typhoon

#undef LOGGING_ENABLED
