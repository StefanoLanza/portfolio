#include "SSAO.h"
#include <core/memoryUtil.h>
#include <graphics/camera.h>
#include <graphics/defaultStates.h>
#include <graphics/device.h>
#include <graphics/deviceUtil.h>
#include <graphics/gpuAllocator.h>
#include <graphics/hlsl.h>
#include <graphics/pipelineRuntime.h>
#include <graphics/pipelineSetup.h>
#include <graphics/shader.h>
#include <graphics/shaderManager.h>
#include <graphics/sortedCommandQueue.h>
#include <graphics/view.h>

namespace Typhoon {

// From https://www.shadertoy.com/view/3tB3z3 - except we're using R2 here
namespace {
#define XE_HILBERT_LEVEL 6U
#define XE_HILBERT_WIDTH ((1U << XE_HILBERT_LEVEL))
#define XE_HILBERT_AREA  (XE_HILBERT_WIDTH * XE_HILBERT_WIDTH)
uint HilbertIndex(uint posX, uint posY) {
	uint index = 0U;
	for (uint curLevel = XE_HILBERT_WIDTH / 2U; curLevel > 0U; curLevel /= 2U) {
		uint regionX = (posX & curLevel) > 0U;
		uint regionY = (posY & curLevel) > 0U;
		index += curLevel * curLevel * ((3U * regionX) ^ regionY);
		if (regionY == 0U) {
			if (regionX == 1U) {
				posX = uint((XE_HILBERT_WIDTH - 1U)) - posX;
				posY = uint((XE_HILBERT_WIDTH - 1U)) - posY;
			}

			uint temp = posX;
			posX = posY;
			posY = temp;
		}
	}
	return index;
}

} // namespace

void SSAOSettings::setEnabled(bool value) {
	enabled = value;
}

bool SSAOSettings::getEnabled() const {
	return enabled;
}

void SSAOSettings::setRadius(float value) {
	radius = std::max(0.01f, value);
}

float SSAOSettings::getRadius() const {
	return radius;
}

void SSAOSettings::setIntensity(float value) {
	intensity = std::clamp(value, 0.f, 1.f);
}

float SSAOSettings::getIntensity() const {
	return intensity;
}

void SSAOSettings::setMaxDepth(float value) {
	maxDepth = std::clamp(value, 1.f, 1000.f);
}

float SSAOSettings::getMaxDepth() const {
	return maxDepth;
}

void SSAOSettings::setBias(float value) {
	bias = std::max(0.f, value);
}

float SSAOSettings::getBias() const {
	return bias;
}

void SSAOSettings::setDepthMipOffset(float value) {
	depthMipOffset = std::clamp(value, 0.f, 5.f);
}

float SSAOSettings::getDepthMipOffset() const {
	return depthMipOffset;
}

void SSAOSettings::setBilateralStrength(float value) {
	bilateralStrength = std::max(0.f, value);
}

float SSAOSettings::getBilateralStrength() const {
	return bilateralStrength;
}

RenderSettings SSAORenderNode::getSettings() {
	return { "SSAO", &settings, getTypeId(&settings) };
}

void SSAORenderNode::initializeShaders(const ShaderManager& shaderManager) {
	samplingPass.shader = shaderManager.findCompiledShaderByName("SSAO_2");
	hrzFilterPass.shader = shaderManager.findCompiledShaderByName("SSAOFiltering");
	vrtFilterPass.shader = hrzFilterPass.shader;
}

void SSAORenderNode::declareResources(PipelineSetup& pipelineSetup) {
	{
		TextureDesc textureDesc {
			.width = 1,
			.height = 1,
			.format = Format::R8_UNORM,
			.levels = 1,
			.arraySize = 1,
			.usage = Usage::Default,
			.bindFlags = BindFlags::ShaderResource | BindFlags::RenderTarget,
		};
		pipelineSetup.declareTexture("SSAORaw", textureDesc, TextureSize::screenRel);
		textureDesc.bindFlags = BindFlags::ShaderResource;
		pipelineSetup.declareTexture("SSAORawPrev", textureDesc, TextureSize::screenRel);
	}
	{
		const TextureDesc textureDesc {
			.width = 1,
			.height = 1,
			.format = Format::R8_UNORM,
			.levels = 1,
			.usage = Usage::Default,
			.bindFlags = BindFlags::ShaderResource | BindFlags::UnorderedAccess,
		};
		pipelineSetup.declareTexture("SSAO_1", textureDesc, TextureSize::screenRel);
		pipelineSetup.declareTexture("SSAO", textureDesc, TextureSize::screenRel, TextureFlag::persistent /* for temporal accumulation*/);
	}
}

void SSAORenderNode::setupPipeline(PipelineSetup& pipelineSetup) {
	// TODO Register settings in pipeline ? For editing

	{
		auto passInfo = pipelineSetup.createPass("SSAO - Store previous");
		passInfo.setEntryPoint([this](auto&&... args) { storePrevious(args...); });
		// Note: cannot bind SSAORaw as input as it creates a circular dep. with the next pass
		passInfo.setCopyDestination("SSAORawPrev");
		// passInfo.setRenderTarget("SSAORawPrev");
	}
	{
		auto passInfo = pipelineSetup.createPass("SSAO - Sampling");
		passInfo.setEntryPoint([this](auto&&... args) { sample(args...); });
		passInfo.setRenderTarget("SSAORaw");
		passInfo.setDepthStencil("mainDepthStencil", DsvFlags::readOnlyDepth);
		passInfo.bindTexture("mainDepthStencil");
		passInfo.bindTexture("depthBufferMipChain");
		passInfo.bindTexture("SSAORawPrev");
		passInfo.bindTexture("motionBuffer");
		samplingPass.passId = passInfo.id();
	}
	{
		auto passInfo = pipelineSetup.createPass("SSAO - Hrz filter");
		passInfo.setEntryPoint([this](auto&&... args) { filter(hrzFilterPass, args...); });
		passInfo.setComputeTarget("SSAO_1");
		passInfo.bindTexture("SSAORaw");
		passInfo.bindTexture("mainDepthStencil");
		passInfo.bindTextureEx("mainDepthStencil", SRVDesc { Format::X32_TYPELESS_G8X24_UINT, 0, (uint)-1 }); // stencil
	}
	{
		auto passInfo = pipelineSetup.createPass("SSAO - Vrt filter");
		passInfo.setEntryPoint([this](auto&&... args) { filter(vrtFilterPass, args...); });
		passInfo.setComputeTarget("SSAO");
		passInfo.bindTexture("SSAO_1");
		passInfo.bindTexture("mainDepthStencil");
		passInfo.bindTextureEx("mainDepthStencil", SRVDesc { Format::X32_TYPELESS_G8X24_UINT, 0, (uint)-1 }); // stencil
	}

	hrzFilterPass.isHorizontalPass = true;
	vrtFilterPass.isHorizontalPass = false;
}

void SSAORenderNode::onDeviceCreated(Device& device) {
	// SSAO passes draw a fullscreen quad, located at maxDepth. Process only pixels within that distance
	// (CmpFunction::less with reverse depth) and stencil marked as GBuffer
	const DepthStencilStateDesc depthStencilDesc {
		true, false, CmpFunction::less, true, false, 0xFF, 0xFF, StencilOp::Keep, StencilOp::Keep, StencilOp::Keep, CmpFunction::equal,
	};
	depthStencilState = device.createDepthStencilState(depthStencilDesc);

	constexpr int width = 64;
	uint16*       data = scratchAllocArray<uint16>(width * width);
	for (int x = 0; x < width; x++) {
		for (int y = 0; y < width; y++) {
			uint32 r2index = HilbertIndex(x, y);
			data[x + width * y] = (uint16)r2index;
		}
	}
	const TextureDesc hilbertTextureDesc {
		.width = width,
		.height = width,
		.format = Format::R16_SNORM,
		.usage = Usage::Immutable,
		.bindFlags = BindFlags::ShaderResource,
	};
	samplingPass.hilbertTexture = device.createTexture(hilbertTextureDesc, data, hilbertTextureDesc.width * sizeof(uint16));
	samplingPass.hilbertSRV = device.createShaderResourceView(samplingPass.hilbertTexture);
	scratchFree(data);
}

void SSAORenderNode::storePrevious(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const {
	// Check pre conditions
	if (! settings.getEnabled()) {
		return;
	}
	const Pass& samplingPassData = pipeline.getResolvedPass(samplingPass.passId);
	for (const RenderView& view : pipeline.getViews(ViewType::main)) {
		CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::copy);
		cmdBuffer->copyResource(pass.targets[0].texture, samplingPassData.targets[0].texture);
		commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, view.subIndex);
	}
}

void SSAORenderNode::sample(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const {
	// Check pre conditions
	if (! settings.getEnabled()) {
		return;
	}
	if (! samplingPass.shader) {
		return;
	}

	GPUAllocator&     gpuAllocator = device.GetAllocator();
	const PassTarget& target = pass.targets[0];

	for (const RenderView& view : pipeline.getViews(ViewType::main)) {
		const ViewportI viewport = makeTopLeftViewport(view.camera.viewport, target.desc.width, target.desc.height);

		const float projScale = target.desc.height / 2.0f * view.camera.projectionMatrix.getElementAsFloat<1, 1>();
		const float intensityDivR6 = settings.getIntensity() / std::pow(settings.getRadius(), 6.0f);

		HLSL_struct PSConstants {
			HLSL_uint2  viewportDim;
			HLSL_float2 pixelSize;
			HLSL_float  projScale;
			HLSL_float  radius;
			HLSL_float  bias;
			HLSL_float  intensityDivR6;
			HLSL_float  depthMipOffset;
			HLSL_float  maxDepth;
			HLSL_uint   frameIndex;
		};
		const PSConstants csConstants = {
			{ (uint)viewport.width, (uint)viewport.height },
			{ 1.f / target.desc.width, 1.f / target.desc.height },
			projScale,
			settings.getRadius(),
			settings.getBias(),
			intensityDivR6,
			settings.getDepthMipOffset(),
			settings.getMaxDepth(),
			pipeline.getFrameIndex(),
		};
		const CBAlloc CB = gpuAllocator.upload(csConstants);

		CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::direct);
		cmdBuffer->setRenderTargets(1, &target.rtv, pass.depthStencil.view);
		cmdBuffer->clearRenderTargetView(target.rtv, 1.f, 1.f, 1.f, 1.f);
		cmdBuffer->setViewport(viewport);
		cmdBuffer->setDepthStencilState(depthStencilState, (uint8)StencilRef::gBuffer);
		cmdBuffer->setRasterizerState(DefStates::solidCcw);
		cmdBuffer->setBlendState(DefStates::blendDisabled);
		cmdBuffer->setShader(samplingPass.shader.get());
		cmdBuffer->setPSResources(0, pass.inputs.view());
		// cmdBuffer->setPSResources(pass.inputs.count, { samplingPass.hilbertSRV });
		cmdBuffer->setVSConstantBuffers(0, { view.cameraCB, CB });
		cmdBuffer->setPSConstantBuffers(0, { view.cameraCB, CB });
		cmdBuffer->setPSSamplers(0, { DefStates::minMagMipPointClamp, DefStates::minMagLinearMipPointClamp });
		cmdBuffer->drawFullScreenTriangle();
		cmdBuffer->unbindRenderTargets();
		cmdBuffer->unbindPSResources();
		commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, view.subIndex);
	}
}

void SSAORenderNode::filter(SSAOFilterPass& filterPass, const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline,
                            Device& device) const {
	if (! filterPass.shader) {
		return;
	}
	if (! settings.getEnabled()) {
		return;
	}

	GPUAllocator& gpuAllocator = device.GetAllocator();

	HLSL_struct Constants {
		HLSL_int2   viewport;
		HLSL_float2 depthInverse;
		HLSL_uint2  dir;
		HLSL_float  bilateralStrength;
	};

	for (const RenderView& view : pipeline.getViews(ViewType::main)) {
		const ViewportI viewport = makeTopLeftViewport(view.camera.viewport, pass.targets[0].desc.width, pass.targets[0].desc.height);
		const auto      threadGroupSize = filterPass.shader->getThreadGroupSize();
		const uint      dispatchX = computeDispatchSize(threadGroupSize[0], filterPass.isHorizontalPass ? viewport.width : viewport.height);
		const uint      dispatchY = filterPass.isHorizontalPass ? viewport.height : viewport.width;

		const Constants psConst = {
			{ viewport.width, viewport.height },
			view.camera.depthInverseProj, //
			filterPass.isHorizontalPass ? HLSL_uint2 { 1, 0 } : HLSL_uint2 { 0, 1 },
			settings.getBilateralStrength(),
		};
		const CBAlloc CB = gpuAllocator.upload(psConst);

		CommandBuffer* cmdBuffer = cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::compute);
		cmdBuffer->setUnorderedAccessViews(0, { pass.targets[0].uav });
		cmdBuffer->setShader(filterPass.shader.get());
		cmdBuffer->setCSConstantBuffers(0, { CB });
		cmdBuffer->setCSResources(0, pass.inputs.view());
		cmdBuffer->dispatch(dispatchX, dispatchY, 1);
		cmdBuffer->unbindUnorderedAccessViews();
		cmdBuffer->unbindCSResources();
		commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, view.subIndex);
	}
}

} // namespace Typhoon
