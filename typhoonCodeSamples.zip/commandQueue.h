#pragma once

#include <core/allocator.h>
#include <core/poolAllocator.h>
#include <core/span.h>
#include <graphics/graphicsTypes.h>

#include <cstdint>
#include <vector>
// std::span cannot be constructed with rvalue initializer_list, breaking all my code

namespace Typhoon {

enum class CommandType : uint8_t;
class LinearAllocator;

struct Command {
	void*          memoryOffset;
	const Command* next;
	CommandType    type;
};

class CommandAllocator final {
public:
	CommandAllocator(Allocator& baseAllocator, CommandBufferFamily family);

	CommandBuffer* newCommandBuffer();
	void           reset();

private:
	Allocator&                   baseAllocator;
	PoolAllocator<CommandBuffer> poolAllocator;
	PagedAllocator               commandAllocator;
	CommandBufferFamily          family;
};

class CommandBuffer final {
public:
	explicit CommandBuffer(LinearAllocator& allocator, CommandBufferFamily family);

	const Command* getRoot() const;
	void           beginEvent(const char* eventName);
	void           beginEventAtFront(const char* eventName);
	void           endEvent();
	void           setMarker(const char* marker);
	void           setRenderTargets(uint numViews, RenderTargetView* const renderTargetViews[], DepthStencilView* depthStencilView);
	void           setRenderTargets(span<RenderTargetView* const> renderTargetViews, DepthStencilView* depthStencilView);
	void           unbindRenderTargets();
	void           clearRenderTargetView(RenderTargetView* rtv, float r, float g, float b, float a);
	void           clearDepthStencilView(DepthStencilView* dsv, Clear clearFlags, float depth, uint8_t stencil);
	void           setUnorderedAccessViews(uint startSlot, span<UnorderedAccessView* const> uavs);
	void           unbindUnorderedAccessViews();
	void           setViewport(const ViewportI& viewport);
	void           setShader(const Shader* shader);
	void           setInputLayout(InputLayout* inputLayout);
	void           setVertexBuffer(GPUBuffer* buffer, uint stride, uint startSlot, uint offset);
	void           setVertexBuffers(uint startSlot, uint numBuffers, GPUBuffer* const vertexBuffers[], const uint strides[],
	                                const uint offsets[]);
	void           setIndexBuffer(GPUBuffer* buffer, IndexFormat indexType, uint offset);
	void           setPrimitiveTopology(PrimitiveType primitiveType);
	void           setBlendState(BlendState state);
	void           setDepthStencilState(DepthStencilState state, uint stencilRef);
	void           setRasterizerState(RasterizerState state);
	void           setScissorRect(const TextureRect& scissorRect);
	void           setVSConstantBuffers(uint startSlot, span<const CBAlloc> cbs);
	void           setVSRawConstantBuffers(uint startSlot, span<GPUBuffer* const> cbs);
	void           setVSResources(uint startSlot, span<ShaderResourceView* const> views);
	void           setPSConstantBuffers(uint startSlot, span<const CBAlloc> cbs);
	void           setPSRawConstantBuffers(uint startSlot, span<GPUBuffer* const> cbs);
	void           setPSResources(uint startSlot, span<ShaderResourceView* const> views);
	void           setGSConstantBuffers(uint startSlot, span<const CBAlloc> cbs);
	void           setGSResources(uint startSlot, span<ShaderResourceView* const> views);
	void           setCSConstantBuffers(uint startSlot, span<const CBAlloc> cbs);
	void           setCSResources(uint startSlot, span<ShaderResourceView* const> views);
	void           setVSSamplers(uint startSlot, span<SamplerState const> samplers);
	void           setPSSamplers(uint startSlot, span<SamplerState const> samplers);
	void           setCSSamplers(uint startSlot, span<SamplerState const> samplers);
	void           setGSSamplers(uint startSlot, span<SamplerState const> samplers);
	void           unbindVSResources();
	void           unbindPSResources();
	void           unbindCSResources();
	void           unbindGSResources();
	void           draw(uint vertexCount, uint startVertexLocation);
	void           drawInstanced(uint vertexCountPerInstance, uint instanceCount, uint startVertexLocation, uint startInstanceLocation);
	void           drawIndexed(uint indexCount, uint startIndexLocation, int baseVertexLocation);
	void           drawIndexedInstanced(uint indexCountPerInstance, uint instanceCount, uint startIndexLocation, int baseVertexLocation,
	                                    uint startInstanceLocation);
	void           drawIndexedInstancedIndirect(GPUBuffer* bufferForArgs, uint alignedByteOffsetForArgs);
	void           dispatch(uint threadGroupCountX, uint threadGroupCountY, uint threadGroupCountZ);
	void           copyResource(Resource* dst, Resource* src);
	void           copySubresourceRegion(Resource* dst, uint dstArraySlice, uint dstMipSlice, uint dstX, uint dstY, Resource* src, uint srcArraySlice,
	                                     uint srcMipSlice, uint srcX, uint srcY, uint srcW, uint srcH);
	void           copySubresourceRegion3D(Resource* dst, uint dstMipSlice, uint dstX, uint dstY, uint dstZ, Resource* src, uint srcMipSlice, uint srcX,
	                                       uint srcY, uint srcZ, uint srcW, uint srcH, uint srcD);
	void           executeBundle(CommandBuffer* bundle);
	void           reset();
	void           close();

	// Utilities
	void drawFullScreenTriangle();

private:
	void* allocCommand(CommandType type, size_t dataSize);
	void* allocCommandAtFront(CommandType type, size_t dataSize);
	void  writeConstantBuffers(uint startSlot, span<const CBAlloc> cbs, CommandType commandType);

private:
	LinearAllocator* allocator;
	const Command*   root;
	Command*         tail;
	uint32_t         flags;
#ifdef _DEBUG
	CommandBufferFamily family;
	uint32_t            queueCount;
	bool                canReset;
#endif
	friend class CommandQueue;
};

class GPUProfiler;

class CommandQueue final {
public:
	explicit CommandQueue(Device& device);

	void executeCommandBuffers(size_t count, const CommandBuffer* const buffers[], GPUProfiler& profiler);

private:
	Device& device;
};

// Computes a compute shader dispatch size given a thread group size, and number of elements to process
inline uint computeDispatchSize(uint tgSize, uint numElements) {
	return (numElements + tgSize - 1) / tgSize;
}

} // namespace Typhoon
