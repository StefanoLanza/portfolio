#include "frustum.h"
#include <DirectXMath/Extensions/DirectXMathExt.h>
#include <math/matrix4f.h>
#include <math/simdScalar.h>
#include <math/simdVector.h>

#include <cassert>

namespace Typhoon {

#define _mm_splat_ps(_a, _i)  _mm_shuffle_ps((_a), (_a), _MM_SHUFFLE(_i, _i, _i, _i))
#define _mm_splat3_ps(_a, _i) _mm_shuffle_ps((_a), (_a), _MM_SHUFFLE(3, _i, _i, _i))

namespace {

int testSpheres(const SimdVector* RESTRICT spheres, int numSpheresDiv4, const SimdVector* RESTRICT planes, int numPlanes,
                uint32_t* RESTRICT visibleIndices, int mask, uint32_t startIndex);
int testAABBs(const AABB* boxes, int numBoxesDiv4, const SimdVector* planes, int numPlanes, const uint32_t* RESTRICT inUserData,
              uint32_t* RESTRICT outUserData, int mask);

} // namespace

Frustum buildFrustumFromMatrix(const Matrix4f& m, const Position& worldOrigin, uint32_t mask) {
	Frustum frustum;
	frustum.worldOrigin = worldOrigin;

	const Matrix4    mt = transposeMatrix(m);
	const SimdVector col0 = mt.getColumn<0>();
	const SimdVector col1 = mt.getColumn<1>();
	const SimdVector col2 = mt.getColumn<2>();
	const SimdVector col3 = mt.getColumn<3>();

	SimdVector planes[Frustum::c_numPlanes];
	planes[Frustum::LEFT_PLANE] = col3 + col0;
	planes[Frustum::RIGHT_PLANE] = col3 - col0;
	planes[Frustum::TOP_PLANE] = col3 - col1;
	planes[Frustum::BOTTOM_PLANE] = col3 + col1;
	planes[Frustum::NEAR_PLANE] = col2;
	planes[Frustum::FAR_PLANE] = col3 - col2;

	int numPlanes = 0;
	for (int i = 0; i < Frustum::c_numPlanes; ++i) {
		if (mask & TY_BIT(i)) {
			// Normalize
			const SimdScalar invLength = lengthInverse<3>(planes[i]);
			planes[i] *= invLength;
			frustum.planes[numPlanes] = planes[i];
			++numPlanes;
		}
	}

	for (int i = numPlanes; i < Frustum::c_numPlanes; ++i) {
		// Disable plane
		frustum.planes[i].SetZero();
	}

	frustum.numPlanes = numPlanes;
	return frustum;
}

int frustumTestAABBs(const Frustum& frustum, const AABB* boxes, int numBoxes, uint32_t* userData) {
	const int numIter = numBoxes / 4;
	int       numVisible = testAABBs(boxes, numIter, frustum.planes, frustum.numPlanes, userData, userData, 0x0F);
	const int numRemaining = numBoxes % 4;
	if (numRemaining) {
		boxes += numIter * 4;
		AABB remainingBoxes[4];
		int  mask = 0;
		for (size_t i = 0; i < numRemaining; ++i) {
			mask |= (1 << i);
			remainingBoxes[i] = boxes[i];
		}
		for (size_t i = numRemaining; i < 4; ++i) {
			remainingBoxes[i].center.SetZero();
			remainingBoxes[i].extents.SetZero();
		}
		numVisible += testAABBs(remainingBoxes, 1, frustum.planes, frustum.numPlanes, userData + numIter * 4, userData + numVisible, mask);
	}
	return numVisible;
}

int frustumTestOBBs(const Frustum& frustum, const OBB* boxes, int numBoxes, uint32_t* visibleIndices) {
	TY_MATH_CHECK_ALIGNMENT(boxes);
	TY_MATH_CHECK_ALIGNMENT(frustum.planes);
	using namespace DirectX;

	const __m128 xmm_signMask = *(__m128*)sseSignMask;

	int      numVisible = 0;
	uint32_t currIndex = 0;
	for (int i = 0; i < numBoxes; ++i) {
		// assert(boxes[i].m_position.m_w == 1.f);
		assert(boxes[i].center.w == 0.f);
		assert(boxes[i].extents.w == 0.f);

		// Compute matrix from world to local space
		const __m128   boxQuat = XMQuaternionConjugate(boxes[i].orientation.quad);
		const XMMATRIX m = XMMatrixRotationQuaternion(boxQuat);

		// Compute box center in local space
		const __m128 boxPosition = XMVector3Transform(boxes[i].position.quad, m);
		const __m128 boxCenter = _mm_add_ps(boxPosition, boxes[i].center.quad);

		const __m128 boxExtent = boxes[i].extents.quad;

		visibleIndices[numVisible] = currIndex;
		++numVisible;
		uint8 res = 1;
		for (int p = 0; p < frustum.numPlanes; ++p) {
			// Transform plane to local space
			const __m128 planeEq = XMPlaneRotate(frustum.planes[p].quad, m);

			// Compute point closest to plane
			const __m128 sign = _mm_and_ps(xmm_signMask, planeEq);
			const __m128 signedBoxExtent = _mm_xor_ps(boxExtent, sign);
			const __m128 closestPoint = _mm_add_ps(boxCenter, signedBoxExtent);

			// Compute distance to plane and reject box if it is entirely behind the plane (dot < 0)
			const __m128 dotp = XMVector4Dot(closestPoint, planeEq);
			const int    in_out_flag = _mm_movemask_ps(dotp);
			if (in_out_flag == 0x0F) // 01111b
			{
				--numVisible;
				res = 0;
				break;
			}
		}
		++currIndex;
	}
	return numVisible;
}

int frustumTestShearedBBs(const Frustum& frustum, const ShearedBB* boxes, int numBoxes, uint32_t* visibleIndices) {
	TY_MATH_CHECK_ALIGNMENT(boxes);
	TY_MATH_CHECK_ALIGNMENT(frustum.planes);
	using namespace DirectX;

	const __m128 xmm_signMask = *reinterpret_cast<const __m128*>(sseSignMask);

	int      numVisible = 0;
	uint32_t currIndex = 0;
	for (int i = 0; i < numBoxes; ++i) {
		const ShearedBB& box = boxes[i];

		// Compute matrix from world to local space
		XMMATRIX worldToLocalMatrix;
		worldToLocalMatrix.r[0] = box.worldToLocal[0].quad;
		worldToLocalMatrix.r[1] = box.worldToLocal[1].quad;
		worldToLocalMatrix.r[2] = box.worldToLocal[2].quad;
		// not used worldToLocalMatrix.r[3] = g_XMIdentityR3;

		// Compute transpose of matrix from local to world space. XMPlaneTransform takes as input the transponse inverse
		XMMATRIX localToWorld;
		localToWorld.r[0] = box.localToWorld[0].quad;
		localToWorld.r[1] = box.localToWorld[1].quad;
		localToWorld.r[2] = box.localToWorld[2].quad;
		localToWorld.r[3] = g_XMIdentityR3;
		XMMATRIX localToWorldTranspose = XMMatrixTranspose(localToWorld);

		// Compute box center in local space
		__m128 boxCenter = XMVector3TransformNormal((box.center - frustum.worldOrigin).quad, worldToLocalMatrix);
		boxCenter = XMVectorSelect(g_XMIdentityR3.v, boxCenter, g_XMSelect1110.v); // boxCenter.w = 1

		const __m128 boxExtents = _mm_and_ps(box.extents.quad, g_XMMask3); // boxExtents.w = 0

		visibleIndices[numVisible] = currIndex;
		++numVisible;
		for (int p = 0; p < frustum.numPlanes; ++p) {
			// Transform plane to local space
			const __m128 planeEq = XMPlaneTransform(frustum.planes[p].quad, localToWorldTranspose);

			// Compute point closest to plane
			const __m128 sign = _mm_and_ps(xmm_signMask, planeEq);
			const __m128 signedBoxExtent = _mm_xor_ps(boxExtents, sign);
			const __m128 closestPoint = _mm_add_ps(boxCenter, signedBoxExtent);

			// Compute distance to plane and reject box if it is entirely behind the plane (dot < 0)
			const __m128 dotp = XMVector4Dot(closestPoint, planeEq);
			const int    in_out_flag = _mm_movemask_ps(dotp);
			if (in_out_flag == 0b1111) {
				--numVisible;
				break;
			}
		}
		++currIndex;
	}
	return numVisible;
}

int frustumTestSpheres(const Frustum& frustum, const SimdVector* spheres, int numSpheres, uint32_t* visibleIndices) {
	const int numIter = numSpheres / 4;
	int       numVisible = testSpheres(spheres, numIter, frustum.planes, frustum.numPlanes, visibleIndices, 0x0F, 0); // 01111b;
	const int numRemaining = numSpheres % 4;
	if (numRemaining) {
		spheres += numIter * 4;
		SimdVector remainingSpheres[4];
		int        mask = 0;
		for (int i = 0; i < numRemaining; ++i) {
			mask |= (1 << i);
			remainingSpheres[i] = spheres[i];
		}
		for (int i = numRemaining; i < 4; ++i) {
			remainingSpheres[i].SetZero();
		}
		numVisible += testSpheres(remainingSpheres, 1, frustum.planes, frustum.numPlanes, visibleIndices + numVisible, mask, numIter * 4);
	}
	return numVisible;
}

bool frustumTestSphere(const Frustum& frustum, SimdVector sphere) {
	uint32_t visibleIndex;
	return (frustumTestSpheres(frustum, &sphere, 1, &visibleIndex) == 0);
}

void translateFrustum(Frustum& frustum, SimdVector_ offset) {
	for (int i = 0; i < frustum.numPlanes; ++i) {
		SimdVector tmp = frustum.planes[i];
		frustum.planes[i].SetXYZ_W(tmp, tmp + dot3(tmp, offset)); // w += dot(plane.xyz, offset)
	}
}

namespace {

int testSpheres(const SimdVector* RESTRICT spheres, int numSpheresDiv4, const SimdVector* RESTRICT planes, int numPlanes,
                uint32_t* RESTRICT visibleIndices, int mask, uint32_t startIndex) {
	TY_MATH_CHECK_ALIGNMENT(spheres);

	const SimdVector* RESTRICT spherePtr = spheres;
	int                        numVisible = 0;
	uint32_t                   currIndex = startIndex;
	for (int i = 0; i < numSpheresDiv4; ++i) {
		__m128 x = spherePtr[0].quad;
		__m128 y = spherePtr[1].quad;
		__m128 z = spherePtr[2].quad;
		__m128 r = spherePtr[3].quad;
		_MM_TRANSPOSE4_PS(x, y, z, r);

		int in_out_flag = mask;
		for (int p = 0; p < numPlanes; ++p) {
			const __m128 planeEq = planes[p].quad;
			__m128       d = _mm_mul_ps(_mm_splat_ps(planeEq, 0), x);
			// d += y * p.y
			d = _mm_add_ps(d, _mm_mul_ps(_mm_splat_ps(planeEq, 1), y));
			// d += z * p.z
			d = _mm_add_ps(d, _mm_mul_ps(_mm_splat_ps(planeEq, 2), z));
			// d += p.w
			d = _mm_add_ps(d, _mm_splat_ps(planeEq, 3));
			// d += r
			d = _mm_add_ps(d, r);

			// in_out_flag_curPlane is 4 bits, 1 if a sphere is outside the frustum, 0 if inside or intersecting
			const int in_out_flag_curPlane = _mm_movemask_ps(d);
			in_out_flag &= ~in_out_flag_curPlane;

			// If all spheres have been marked as outside the frustum, stop checking the rest of the planes.
			if (in_out_flag == 0) {
				break;
			}
		}
		// FIXME Which is faster?
#if 1
		if (in_out_flag & 1) {
			visibleIndices[numVisible++] = currIndex + 0;
		}
		if (in_out_flag & 2) {
			visibleIndices[numVisible++] = currIndex + 1;
		}
		if (in_out_flag & 4) {
			visibleIndices[numVisible++] = currIndex + 2;
		}
		if (in_out_flag & 8) {
			visibleIndices[numVisible++] = currIndex + 3;
		}
#else
		visibleIndices[numVisible] = currIndex + 0;
		numVisible += in_out_flag & 1;
		visibleIndices[numVisible] = currIndex + 1;
		numVisible += (in_out_flag & 2) >> 1;
		visibleIndices[numVisible] = currIndex + 2;
		numVisible += (in_out_flag & 4) >> 2;
		visibleIndices[numVisible] = currIndex + 3;
		numVisible += (in_out_flag & 8) >> 3;
#endif
		spherePtr += 4;
		currIndex += 4;
	}
	return numVisible;
}

int testAABBs(const AABB* boxes, int numBoxesDiv4, const SimdVector* planes, int numPlanes, const uint32_t* RESTRICT inUserData,
              uint32_t* RESTRICT outUserData, int mask) {
	TY_MATH_CHECK_ALIGNMENT(boxes);
	TY_MATH_CHECK_ALIGNMENT(planes);

	__m128       absPlanes[Frustum::c_numPlanes];
	const __m128 xmm_signMask = *(__m128*)sseSignMask;
	for (int p = 0; p < numPlanes; ++p) {
		absPlanes[p] = _mm_andnot_ps(xmm_signMask, planes[p].quad);
	}

	int         numVisible = 0;
	const AABB* boxPtr = boxes;
	for (int i = 0; i < numBoxesDiv4; ++i) {
		__m128 center_x = boxPtr[0].center.quad;
		__m128 center_y = boxPtr[1].center.quad;
		__m128 center_z = boxPtr[2].center.quad;
		__m128 center_w = boxPtr[3].center.quad;
		_MM_TRANSPOSE4_PS(center_x, center_y, center_z, center_w);
		__m128 extent_x = boxPtr[0].extents.quad;
		__m128 extent_y = boxPtr[1].extents.quad;
		__m128 extent_z = boxPtr[2].extents.quad;
		__m128 extent_w = boxPtr[3].extents.quad;
		_MM_TRANSPOSE4_PS(extent_x, extent_y, extent_z, extent_w);

		int in_out_flag = mask;
		for (int p = 0; p < numPlanes; ++p) {
			// Calculate d
			__m128 plane_comp, d;
			plane_comp = _mm_splat_ps(planes[p].quad, 0);
			d = _mm_mul_ps(plane_comp, center_x);

			plane_comp = _mm_splat_ps(planes[p].quad, 1);
			d = _mm_add_ps(d, _mm_mul_ps(plane_comp, center_y));

			plane_comp = _mm_splat_ps(planes[p].quad, 2);
			d = _mm_add_ps(d, _mm_mul_ps(plane_comp, center_z));

			// Calculate r
			__m128 r;
			r = _mm_mul_ps(extent_x, _mm_splat_ps(absPlanes[p], 0));

			plane_comp = _mm_mul_ps(extent_y, _mm_splat_ps(absPlanes[p], 1));
			r = _mm_add_ps(r, plane_comp);

			plane_comp = _mm_mul_ps(extent_z, _mm_splat_ps(absPlanes[p], 2));
			r = _mm_add_ps(r, plane_comp);

			// Calculate d + r + plane.d
			__m128 d_p_r = _mm_add_ps(d, r);
			d_p_r = _mm_add_ps(d_p_r, _mm_splat_ps(absPlanes[p], 3));

			int in_out_flag_curPlane = _mm_movemask_ps(d_p_r);
			in_out_flag &= ~in_out_flag_curPlane;

			// If all boxes have been marked as outside the frustum, stop checking the rest of the planes.
			if (! in_out_flag) {
				break;
			}
		}
#if 0
		if (in_out_flag & 1)
		{
			outUserData[numVisible] = inUserData[0];
			++numVisible;
		}
		if (in_out_flag & 2)
		{
			outUserData[numVisible] = inUserData[1];
			++numVisible;
		}
		if (in_out_flag & 4)
		{
			outUserData[numVisible] = inUserData[2];
			++numVisible;
		}
		if (in_out_flag & 8)
		{
			outUserData[numVisible] = inUserData[3];
			++numVisible;
		}
#else
		outUserData[numVisible] = inUserData[0];
		numVisible += in_out_flag & 1;
		outUserData[numVisible] = inUserData[1];
		numVisible += (in_out_flag & 2) >> 1;
		outUserData[numVisible] = inUserData[2];
		numVisible += (in_out_flag & 4) >> 2;
		outUserData[numVisible] = inUserData[3];
		numVisible += (in_out_flag & 8) >> 3;
#endif
		inUserData += 4;
		boxPtr += 4;
	}

	return numVisible;
}

} // namespace

} // namespace Typhoon
