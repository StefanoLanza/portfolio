#pragma once

#include <graphics/renderNode.h>
#include <graphics/sphereGeometry.h>

namespace Typhoon {

struct PointLightPreprocessPass {
	ShaderPtr        shader;
	ConstantBufferId pointLightsCBId;
	DataBlobId       volumetricRangeId;
};

struct PointLightShadowPass {
	static constexpr int maxShadowMaps = 2;
	static constexpr int shadowMapSize = 512;
	DepthStencilView*    shadowMapDsv[6 * maxShadowMaps] {};
	RasterizerState      rasterizerState;
};

struct PointLightRenderPass {
	ShaderPtr    shader;
	uint         shaderBindPoints[3] {};
	bool         validShader = false;
	SamplerState samplerState;
};

class PointLightRenderer final : public RenderNode {
public:
	void setDebugEnabled(bool value);
	bool getDebugEnabled() const;
	void initializeShaders(const ShaderManager& shaderManager) override;
	void declareResources(PipelineSetup& pipelineSetup) override;
	void setupPipeline(PipelineSetup& pipelineSetup) override;
	void onShadersRecompiled(Device& device) override;
	void onDeviceCreated(Device& device) override;
	void onDeviceDestroyed(Device& device) override;
	void debug(DrawUtilities& drawUtils, const RenderView& view) const override;

private:
	void setupViews(PipelineRuntime& pipeline, Device& device);
	void cullLights(PipelineRuntime& pipeline, Device& device) const;
	void preprocessLights(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const;
	void renderLights(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const;
	void renderShadows(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device);
	void createShadowMapViews(Device& device, Texture* depthTexture);

private:
	static const int maxVisibleLights;

	bool                     debugEnabled = false;
	SphereGeometry           sphereGeometry;
	PointLightPreprocessPass preprocessPass {};
	PointLightRenderPass     renderPass {};
	PointLightShadowPass     shadowPass {};
	DataBlobId               visibleLightCountId;
	ConstantBufferId         lightConstantsId;
	DataBlobId               shadowMapIndexId;
	DataBlobId               shadowMapProjId;
};

} // namespace Typhoon
