#include "pointLightRenderer.h"
#include "pointLight.h"
#include "pointLightSystem.h"

#include <DrawUtils/drawUtils.h>
#include <core/allocator.h>
#include <core/memoryUtil.h>
#include <graphics/camera.h>
#include <graphics/defaultStates.h>
#include <graphics/device.h>
#include <graphics/deviceUtil.h>
#include <graphics/gpuAllocator.h>
#include <graphics/hlsl.h>
#include <graphics/pipelineRuntime.h>
#include <graphics/pipelineSetup.h>
#include <graphics/shader.h>
#include <graphics/shaderManager.h>
#include <graphics/sortedCommandQueue.h>
#include <graphics/view.h>
#include <logging/logger.h>
#include <math/frustum.h>
#include <scene/scene.h>

#include <cassert>

namespace Typhoon {

namespace {

CBAlloc uploadLights(GPUAllocator& gpuAllocator, const PointLight* lights, const uint32* indices, int count, const uint8* shadowMapIndex,
                     const Float4* shadowMapProj) {
	struct alignas(16) Header {
		HLSL_uint   count;
		HLSL_float4 shadowmapInvSize;
		HLSL_float4 shadowMapProj[PointLightShadowPass::maxShadowMaps];
	};
	struct alignas(16) GPULight {
		Vector3f position;
		float    radius;
		Vector3f radiantIntensity;
		float    invRadius;
		uint     shadowMapIndex;
		float    normalBias;
		float    scatteringIntensity;
	};

	auto [cb, mappedData] = gpuAllocator.map<uint8>(sizeof(Header) + count * sizeof(GPULight));
	if (mappedData) {
		Header header {
			.count = static_cast<uint32>(count),
			.shadowmapInvSize = hlslTextureDim(PointLightShadowPass::shadowMapSize, PointLightShadowPass::shadowMapSize),
		};
		for (int i = 0; i < PointLightShadowPass::maxShadowMaps; ++i) {
			header.shadowMapProj[i] = shadowMapProj[i];
		}
		std::memcpy(mappedData, &header, sizeof header);
		mappedData += sizeof header;

		volatile auto gpuLight = reinterpret_cast<GPULight*>(mappedData);
		for (int i = 0; i < count; ++i) {
			const PointLight& light = lights[indices[i]];
			light.position.StoreA<4>(&gpuLight->position.x);
			gpuLight->radius = light.radius;
			gpuLight->radiantIntensity = light.radiantIntensity;
			gpuLight->invRadius = 1.f / light.radius;
			gpuLight->shadowMapIndex = shadowMapIndex[i];
			gpuLight->normalBias = light.normalBias * (2.f * header.shadowmapInvSize.el[2]);
			gpuLight->scatteringIntensity = light.scatteringIntensity;
			++gpuLight;
		}
		gpuAllocator.unmap(cb);
	}
	return cb;
}

} // namespace

const int PointLightRenderer::maxVisibleLights = 512;

void PointLightRenderer::setDebugEnabled(bool value) {
	debugEnabled = value;
}

bool PointLightRenderer::getDebugEnabled() const {
	return debugEnabled;
}

void PointLightRenderer::initializeShaders(const ShaderManager& shaderManager) {
	preprocessPass.shader = shaderManager.findCompiledShaderByName("pointLightPreprocess");
	renderPass.shader = shaderManager.findCompiledShaderByName("pointLight");
}

void PointLightRenderer::declareResources(PipelineSetup& pipelineSetup) {
	const TextureDesc textureDesc {
		.width = shadowPass.shadowMapSize,
		.height = shadowPass.shadowMapSize,
		.format = Format::R16_TYPELESS,
		.levels = 1,
		.arraySize = 6 * shadowPass.maxShadowMaps,
		// null render target so as not to render color
		.bindFlags = BindFlags::DepthStencil | BindFlags::ShaderResource,
	};
	const SRVDesc srvDesc {
		.format = Format::R16_UNORM,
	};
	pipelineSetup.declareTexture("pointLights.shadowMap", textureDesc, &srvDesc);

	pipelineSetup.declareStructuredBuffer("pointLights.mediaDensity", sizeof(float) * maxVisibleLights, sizeof(float));

	lightConstantsId = pipelineSetup.declareConstantBuffer("pointLights.cb");
	visibleLightCountId = pipelineSetup.declareData<int>("pointLights.count");
	shadowMapIndexId = pipelineSetup.declareData<uint8*>("pointLights.shadowMapIndex");
	shadowMapProjId = pipelineSetup.declareData<Float4*>("pointLights.shadowMapProj");
}

void PointLightRenderer::setupPipeline(PipelineSetup& pipelineSetup) {
	{
		auto passInfo = pipelineSetup.createPass("Point lights preprocess");
		passInfo.setEntryPoint([this](auto&&... args) { preprocessLights(args...); });
		passInfo.setTargetBuffer("pointLights.mediaDensity");
		passInfo.bindTexture("volumetric.mediaTexture");
		preprocessPass.pointLightsCBId = passInfo.bindConstants("pointLights.cb");
		preprocessPass.volumetricRangeId = passInfo.bindData("volumetric.range");
	}
	{
		auto passInfo = pipelineSetup.createPass("Point lights shadows", PassPriority::shadowMap);
		passInfo.setEntryPoint([this](auto&&... args) { renderShadows(args...); });
		passInfo.setDepthStencil("pointLights.shadowMap", DsvFlags::none);
	}

	{
		auto passInfo = pipelineSetup.createChildPass("Point lights", "LightPrePass");
		passInfo.setEntryPoint([this](auto&&... args) { renderLights(args...); });
		passInfo.setBlending();
		passInfo.bindTexture("pointLights.shadowMap");
		passInfo.bindBuffer("pointLights.mediaDensity");
	}

	// TODO Support CPU jobs with dependencies in work graph
	pipelineSetup.registerFrameJob([this](auto&&... args) { setupViews(args...); });
	pipelineSetup.registerCPUJob([this](auto&&... args) { cullLights(args...); });
}

void PointLightRenderer::onShadersRecompiled([[maybe_unused]] Device& device) {
	if (renderPass.shader) {
		renderPass.shaderBindPoints[0] = renderPass.shader->getBindPoint("lights");
		renderPass.shaderBindPoints[1] = renderPass.shader->getBindPoint("shadowMap");
		renderPass.shaderBindPoints[2] = renderPass.shader->getBindPoint("samplerComparisonLess");
	}
}

void PointLightRenderer::onDeviceDestroyed([[maybe_unused]] Device& device) {
	shadowPass.shadowMapDsv[0] = nullptr; // force creation
}

void PointLightRenderer::onDeviceCreated(Device& device) {
	sphereGeometry.createBuffer(device, 16, 8);

	{
		const SamplerStateDesc comparisonLessDesc = {
			Filter::COMPARISON_MIN_MAG_LINEAR_MIP_POINT,
			TexAddress::clamp,
			TexAddress::clamp,
			TexAddress::clamp,
			0.f,
			0,
			{ 1, 1, 1, 1 },
			0.f,
			0.f,
			CmpFunction::less,
		};
		renderPass.samplerState = device.createSamplerState(comparisonLessDesc);
	}
	{
		const RasterizerStateDesc rasterizerStateDesc {
			.slopeScaledDepthBias = 2.f,
			.depthClipEnable = false,
		};
		shadowPass.rasterizerState = device.createRasterizerState(rasterizerStateDesc);
	}
}

void PointLightRenderer::debug(DrawUtilities& drawUtils, const RenderView& view) const {
	if (! debugEnabled) {
		return;
	}
	const SimdVector color { 1, 1, 0, 1 };
	const auto       lightSystem = view.scene->querySystem<PointLightSystem>();
	for (const auto& light : lightSystem->getLights()) {
		drawUtils.drawSphere(light.position + view.camera.worldOrigin, light.radius, color);
	}
}

void PointLightRenderer::setupViews(PipelineRuntime& pipeline, [[maybe_unused]] Device& device) {
	LinearAllocator& scratchAllocator = getGlobalScratchAllocator(); // FIXME not thread safe
	LinearAllocator& frameAllocator = pipeline.getFrameAllocator();

	const Scene* prevScene = nullptr;
	for (const RenderView& mainView : pipeline.getAllMainViews()) {
		if (mainView.scene == prevScene) {
			// Shadowmap is the same
			continue;
		}
		prevScene = mainView.scene;

		const auto lightSystem = mainView.scene->querySystem<PointLightSystem>();
		const auto lights = lightSystem->getLights();

		// FIXME Not per view
		Float4* shadowMapProj = frameAllocator.allocArray<Float4>(shadowPass.maxShadowMaps);
		uint8*  shadowIndex = frameAllocator.allocArray<uint8>(lights.size());
		std::memset(shadowIndex, 255, lights.size());

		// Set even if no casters since needed by uploadLights
		pipeline.setData(shadowMapIndexId, shadowIndex, mainView.sceneDataBucket);
		pipeline.setData(shadowMapProjId, shadowMapProj, mainView.sceneDataBucket);

		MemoryScope       memoryScope { scratchAllocator };
		SimdVector* const bspheres = scratchAllocator.allocArray<SimdVector>(lights.size());
		uint32* const     casterIndices = scratchAllocator.allocArray<uint32>(lights.size());

		// Build an array of all shadow casting lights
		int    numCasters = 0;
		uint32 lightIdx = 0;
		for (auto const& light : lights) {
			if (light.castsShadows) {
				bspheres[numCasters].SetXYZ_W(light.position, SimdScalar { light.radius });
				casterIndices[numCasters] = lightIdx;
				++numCasters;
			}
			++lightIdx;
		}

		// Frustum cull shadow casters
		uint32* const visibleIndices = scratchAllocator.allocArray<uint32>(numCasters);
		int           numVisibleCasters = frustumTestSpheres(mainView.frustum, bspheres, numCasters, visibleIndices);
		if (0 == numVisibleCasters) {
			continue;
		}
		if (numVisibleCasters > shadowPass.maxShadowMaps) {
			LogWarning("Too many visible point shadow caster");
		}
		numVisibleCasters = std::min(shadowPass.maxShadowMaps, numVisibleCasters);

		// Compact indices
		for (int i = 0; i < numVisibleCasters; ++i) {
			casterIndices[i] = casterIndices[visibleIndices[i]];
		}

		// TODO Combine visible casters of multiple views
		for (int i = 0; i < numVisibleCasters; ++i) {
			const auto& light = lights[casterIndices[i]];

			// Use a camera with a field of view of 90 degrees
			const Matrix4f projMatrix = matrixPerspectiveFOV(1.f, 1.f, 0.1f, light.radius);
			projMatrix.getRow<2>().Store(&shadowMapProj[i]);
			shadowIndex[casterIndices[i]] = static_cast<uint8>(i);

			for (int face = 0; face < 6; ++face) {
				// Setup shadow camera
				Camera shadowCamera;
				setDefaultCamera(shadowCamera);
				Matrix4f viewMatrix = matrixGetCubeMapView(face);
				setCameraViewTransform(shadowCamera, viewMatrix, light.position + mainView.camera.worldOrigin, mainView.camera.worldOrigin);
				setCameraProjectionMatrix(shadowCamera, projMatrix);
				commitCameraChanges(shadowCamera);

				pipeline.createView(mainView.canvasId, ViewType::pointShadows, shadowCamera, Frustum::allMask);
			}
		}
	}
}

void PointLightRenderer::cullLights(PipelineRuntime& pipeline, Device& device) const {
	LinearAllocator& scratchAllocator = getGlobalScratchAllocator(); // FIXME Not thread safe
	GPUAllocator&    gpuAllocator = device.GetAllocator();
	for (const RenderView& view : pipeline.getViews(ViewType::main)) {
		const auto   lightSystem = view.scene->querySystem<PointLightSystem>();
		const auto   lights = lightSystem->getLights();
		const size_t numLights = lights.size();

		MemoryScope   memoryScope { scratchAllocator };
		SimdVector*   bspheres = scratchAllocator.allocArray<SimdVector>(numLights);
		uint32* const visibleIndices = scratchAllocator.allocArray<uint32>(numLights);
		uint32* const sphereToLight = scratchAllocator.allocArray<uint32>(numLights);

		// Frustum and distance culling
		int numSpheres = 0;
		for (size_t i = 0; i < numLights; ++i) {
			SimdVector diff = lights[i].position - view.camera.position;
			if (lengthSquared<3>(diff).getFloat() < lights[i].squareCullDistance) {
				bspheres[numSpheres].SetXYZ_W(lights[i].position, SimdScalar(lights[i].radius));
				sphereToLight[numSpheres] = static_cast<uint32>(i);
				numSpheres++;
			}
		}
		const int numVisibleLights = frustumTestSpheres(view.frustum, bspheres, numSpheres, visibleIndices);

		// Fix indices
		for (int i = 0; i < numVisibleLights; ++i) {
			visibleIndices[i] = sphereToLight[visibleIndices[i]];
		}

		// Note: always upload count, even when numVisible == 0
		const uint8* shadowMapIndex = pipeline.getData<const uint8*>(shadowMapIndexId, view.sceneDataBucket, nullptr);
		assert(shadowMapIndex);
		const Float4* shadowMapProj = pipeline.getData<const Float4*>(shadowMapProjId, view.sceneDataBucket, nullptr);
		const auto    lightCB = uploadLights(gpuAllocator, lights.data(), visibleIndices, numVisibleLights, shadowMapIndex, shadowMapProj);
		if (! lightCB.buffer) {
			continue;
		}
		pipeline.setConstants(lightConstantsId, lightCB, view.dataBucket);
		pipeline.setData(visibleLightCountId, numVisibleLights, view.dataBucket);
	}
}

void PointLightRenderer::preprocessLights(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline,
                                          Device& device) const {
	if (! preprocessPass.shader) {
		return;
	}
	assert(pass.outBufferCount == 1);

	const Vector3f volumetricRangeParams =
	    pipeline.getData<Vector3f>(preprocessPass.volumetricRangeId, pipeline.globals, { 0.f, 0.f, 0.f });

	for (const RenderView& view : pipeline.getViews(ViewType::main)) {
		const CBAlloc pointLightsCB = pipeline.getConstants(preprocessPass.pointLightsCBId, view.dataBucket);

		HLSL_struct Constants {
			HLSL_float3 volumetricRangeParams;
		};
		const Constants constants {
			volumetricRangeParams,
		};
		const CBAlloc cb = device.GetAllocator().upload(constants);

		CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::compute);
		cmdBuffer->setUnorderedAccessViews(0, { pass.targets[0].uav });
		cmdBuffer->setShader(preprocessPass.shader.get());
		cmdBuffer->setCSConstantBuffers(0, { view.cameraCB, pointLightsCB, cb });
		cmdBuffer->setCSSamplers(0, { DefStates::minMagLinearMipPointClamp });
		cmdBuffer->setCSResources(0, pass.inputs.view());
		cmdBuffer->dispatch(1, 1, 1);
		cmdBuffer->unbindUnorderedAccessViews();
		commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, 0);
	}
}

void PointLightRenderer::renderLights(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const {
	for (const RenderView& view : pipeline.getViews(ViewType::main)) {
		const int visibleLightCount = pipeline.getData<int>(visibleLightCountId, view.dataBucket, 0);
		if (0 == visibleLightCount) {
			continue;
		}
		const CBAlloc lightCB = pipeline.getConstants(lightConstantsId, view.dataBucket);

		CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::bundle);
		cmdBuffer->beginEvent("Point lights");
		cmdBuffer->setBlendState(DefStates::blendOneSrcOne);
		cmdBuffer->setShader(renderPass.shader.get());
		cmdBuffer->setVSConstantBuffers(renderPass.shaderBindPoints[0], { lightCB });
		cmdBuffer->setPSConstantBuffers(renderPass.shaderBindPoints[0], { lightCB });
		if (renderPass.shaderBindPoints[1] != invalidBindPoint) {
			cmdBuffer->setPSResources(renderPass.shaderBindPoints[1], pass.inputs.view());
		}
		if (renderPass.shaderBindPoints[2] != invalidBindPoint) {
			cmdBuffer->setPSSamplers(renderPass.shaderBindPoints[2], { renderPass.samplerState });
		}
		sphereGeometry.render(cmdBuffer);
		cmdBuffer->drawIndexedInstanced(sphereGeometry.getIndexCount(), visibleLightCount, 0, 0, 0);
		cmdBuffer->endEvent();
		commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, 0, 2 /*after dir lights*/);
	}
}

void PointLightRenderer::renderShadows(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) {
	if (! shadowPass.shadowMapDsv[0]) {
		createShadowMapViews(device, pass.depthStencil.texture);
	}
	const ViewportI viewport = defaultViewport(shadowPass.shadowMapSize, shadowPass.shadowMapSize);
	const auto      shadowViews = pipeline.getViews(ViewType::pointShadows);
	for (const RenderView& shadowView : shadowViews) {
		{
			// For each shadowmap
			CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::direct);
			if (shadowView.subIndex == 0) {
				// Common to all sub views
				cmdBuffer->setViewport(viewport);
				cmdBuffer->setBlendState(DefStates::blendDisabled);
				cmdBuffer->setDepthStencilState(DefStates::depthOnWriteOn, 0);
				cmdBuffer->setRasterizerState(shadowPass.rasterizerState);
			}
			cmdBuffer->setRenderTargets(0, nullptr, shadowPass.shadowMapDsv[shadowView.subIndex]);
			// Clear target to maximum color == maximum distance for shadowmaps (1)
			cmdBuffer->clearDepthStencilView(shadowPass.shadowMapDsv[shadowView.subIndex], Clear::depth, 1.f, 0);
			cmdBuffer->setVSConstantBuffers(0, { shadowView.cameraCB });
			commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, shadowView.subIndex, CmdBufferPriority::beginView);
		}
		if (shadowView.subIndex == shadowViews.size() - 1) {
			// End shadow pass
			CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::direct);
			cmdBuffer->unbindRenderTargets();
			commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, shadowView.subIndex, CmdBufferPriority::endView);
		}
	}
}

void PointLightRenderer::createShadowMapViews(Device& device, Texture* depthTexture) {
	assert(! shadowPass.shadowMapDsv[0]);
	for (int i = 0; i < 6 * shadowPass.maxShadowMaps; ++i) {
		const DepthStencilViewDesc dsvDesc {
			.mipSlice = 0,
			.flags = DsvFlags::none,
			.firstArraySlice = (uint)i,
		};
		shadowPass.shadowMapDsv[i] = device.createDepthStencilView(depthTexture, &dsvDesc);
	}
}

} // namespace Typhoon
