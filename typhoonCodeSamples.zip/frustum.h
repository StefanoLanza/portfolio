#pragma once

#include <math/boundingShapes.h>
#include <math/position.h>
#include <math/simdVector.h>

namespace Typhoon {

struct Frustum final {
	enum PlaneIndex {
		NEAR_PLANE = 0,
		LEFT_PLANE,
		RIGHT_PLANE,
		TOP_PLANE,
		BOTTOM_PLANE,
		FAR_PLANE
	};
	enum PlaneMask {
		noneMask = 0,
		nearMask = TY_BIT(0),
		leftMask = TY_BIT(1),
		rightMask = TY_BIT(2),
		topMask = TY_BIT(3),
		bottomMask = TY_BIT(4),
		farMask = TY_BIT(5),
		allMask = 0xFF
	};

	static constexpr int c_numPlanes = 6;

	Position   worldOrigin;
	SimdVector planes[c_numPlanes];
	int        numPlanes;
};

//! Build a view frustum from a view and projection matrix
/*!\param worldToClipMatrix combined world, view and projection matrix
 */
Frustum buildFrustumFromMatrix(const Matrix4f& worldToClipMatrix, const Position& worldOrigin, uint32_t mask = 0xFF);

// FIXME Inconsistent API. Some functions fill an array of indices, some rearrange/compact userData
int  frustumTestAABBs(const Frustum& frustum, const AABB* boxes, int numBoxes, uint32_t* userData);
int  frustumTestOBBs(const Frustum& frustum, const OBB* boxes, int numBoxes, uint32_t* visibleIndices);
int  frustumTestShearedBBs(const Frustum& frustum, const ShearedBB* boxes, int numBoxes, uint32_t* visibleIndices);
int  frustumTestSpheres(const Frustum& frustum, const SimdVector* spheres, int numSpheres, uint32_t* userData);
bool  frustumTestSphere(const Frustum& frustum, SimdVector);
void translateFrustum(Frustum& frustum, SimdVector_ offset);

} // namespace Typhoon
