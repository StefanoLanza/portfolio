#include <models/model.h>
#include <models/modelManager.h>
#include <models/modelRenderNode.h>
#include <models/modelResource.h>
#include <models/modelSystem.h>

#include <DrawUtils/drawUtils.h>
#include <core/memoryUtil.h>
#include <graphics/camera.h>
#include <graphics/defaultStates.h>
#include <graphics/device.h>
#include <graphics/deviceUtil.h>
#include <graphics/gpuAllocator.h>
#include <graphics/hlsl.h>
#include <graphics/material.h>
#include <graphics/materialManager.h>
#include <graphics/pipelineRuntime.h>
#include <graphics/pipelineSetup.h>
#include <graphics/shader.h>
#include <graphics/shaderManager.h>
#include <graphics/sortedCommandQueue.h>
#include <graphics/view.h>
#include <logging/logger.h>
#include <math/frustum.h>
#include <math/mathUtils.h>
#include <scene/scene.h>
#include <tracy/Tracy.hpp>

#include <algorithm>

namespace Typhoon {

namespace {

uint32 computeLOD(const Model& model, const Camera& camera, uint32 surfaceIndex, SimdVector instancePos, float instanceScale, float lodK,
                  int lodBias) {
	const Surface& surface = model.surfaces[surfaceIndex];
	if (lodK <= 0.f) {
		return surface.startMeshIndex; // lod disabled
	}

	// Evaluate from coarsest to most detailed
	int lodIndex = 0;
	for (int l = surface.lodCount - 1; l > 0; --l) {
		const Mesh& mesh = model.meshes[surface.startMeshIndex + l];

		const float e = mesh.error * instanceScale;
		const float r = surface.bsphere.w;

		// ref: Visualization of large terrains made easy
		SimdVector bsphere;
		bsphere.Load(surface.bsphere);
		bsphere *= SimdScalar { instanceScale };
		if (square(e * lodK + r) < lengthSquared<3>(instancePos + bsphere - camera.position).getFloat()) {
			lodIndex = l;
			break;
		}
	}

	lodIndex = std::clamp(lodIndex + lodBias, 0, (int)surface.lodCount - 1);

	return lodIndex + surface.startMeshIndex;
}

int cullModels(uint32* indices, uint16* meshIndices, const ModelInstance* instances, int instanceCount, const RenderView& view,
               const ModelManager& modelManager, const MaterialManager& materialManager, float lodThreshold, int lodBias) {
	LinearAllocator& scratchAllocator = getGlobalScratchAllocator();
	MemoryScope      rootAutoMemoryBlock(scratchAllocator);

	//	MaterialId currMaterialId;
	//	uint32     shaderTags = 0;
	int numVisible = instanceCount;

	// Precompute for lod
	const float fl = view.camera.projectionMatrix.getElementAsFloat<0, 0>();
	const float lodK = lodThreshold > 0.f ? (0.5f * fl) / lodThreshold : -1.f;

	// Cull instances as bounding spheres
	{
		ZoneScopedN("Cull models as spheres");
		MemoryScope memoryScope { scratchAllocator };
		SimdVector* bspheres = scratchAllocator.allocArray<SimdVector>(numVisible);
		int         numSpheres = 0;
		for (int i = 0; i < numVisible; ++i) {
			const ModelInstance& instance = instances[i];
			if (! materialManager.isValid(instance.materialId)) {
				continue;
			}

			const Model& model = modelManager.getModelUnchecked(instance.modelId);
			const uint32 meshIndex =
			    computeLOD(model, view.camera, instance.surfaceIndex, instance.position, instance.scale, lodK, lodBias);

			const Mesh& mesh = model.meshes[meshIndex];
			SimdVector  scaledSphere;
			scaledSphere.Load(mesh.bsphere);
			scaledSphere *= SimdScalar { instance.scale };

			SimdVector sphereCenter = instance.position + rotate(instance.orientation, scaledSphere);

			// Distance culling
			const SimdVector fromCamera = sphereCenter - view.camera.position;
			const float      sqrDistance = lengthSquared<3>(fromCamera).getFloat();
			if (sqrDistance > instance.squareCullDistance) {
				continue;
			}

			bspheres[numSpheres].SetXYZ_W(sphereCenter, scaledSphere); // .xyz = center, .w = radius
			indices[numSpheres] = i;
			meshIndices[numSpheres] = static_cast<uint16>(meshIndex);
			++numSpheres;
		}

		uint32* visibleIndices = scratchAllocator.allocArray<uint32>(numSpheres);
		numVisible = frustumTestSpheres(view.frustum, bspheres, numSpheres, visibleIndices);
		// Compact indices
		for (int i = 0; i < numVisible; ++i) {
			indices[i] = indices[visibleIndices[i]];
			meshIndices[i] = meshIndices[visibleIndices[i]];
		}

#ifdef TRACY_ENABLE
		char debugStr[64];
		sprintf(debugStr, "Tested/visible spheres: %d/%d", numSpheres, numVisible);
		ZoneText(debugStr, std::strlen(debugStr));
#endif
	}

	// Cull instances as oriented bounding boxes
	{
		ZoneScopedN("Cull models as OOBBs");
		MemoryScope memoryScope { scratchAllocator };
		OBB*        boxes = scratchAllocator.allocArray<OBB>(numVisible);
		int         numBoxes = numVisible;
		for (int i = 0; i < numVisible; ++i) {
			const ModelInstance& instance = instances[indices[i]];
			const Model&         model = modelManager.getModelUnchecked(instance.modelId);
			const Mesh&          mesh = model.meshes[meshIndices[i]];

			SimdVector bboxCenter, bboxDiag;
			bboxCenter.Load(mesh.bboxCenter);
			bboxDiag.Load(mesh.bboxDiag);
			const SimdScalar scale(instance.scale);

			boxes[i].position = instance.position;
			boxes[i].center = bboxCenter * scale; // .w == 0
			boxes[i].extents = bboxDiag * scale;  // .w == 0
			boxes[i].orientation = instance.orientation;
		}
		uint32* visibleIndices = scratchAllocator.allocArray<uint32>(numBoxes);
		numVisible = frustumTestOBBs(view.frustum, boxes, numBoxes, visibleIndices);
		// Compact indices
		for (int i = 0; i < numVisible; ++i) {
			indices[i] = indices[visibleIndices[i]];
			meshIndices[i] = meshIndices[visibleIndices[i]];
		}
#ifdef TRACY_ENABLE
		char debugStr[64];
		sprintf(debugStr, "Tested/visible OOBBs: %d/%d", numBoxes, numVisible);
		ZoneText(debugStr, std::strlen(debugStr));
#endif
	}
	return numVisible;
}

uint setMaterial(CommandBuffer* cmdBuffer, const Material& material, int variant) {
	ZoneScoped;

	assert(material.variantMask);

	constexpr int      numBindPoints = 2;
	static const char* bindPointName[numBindPoints] = { "material", "meshConst" };

	// Set shader
	const Shader& shader = *material.shaderVariants[variant];
	cmdBuffer->setShader(&shader);

	uint bindPoints[numBindPoints];
	shader.getBindPoints(bindPoints, bindPointName);
	const ShaderBindings& shaderBindings = material.shaderBindings[variant];

	// Set textures
	if (shaderBindings.srvCount > 0) {
		cmdBuffer->setPSResources(shaderBindings.srvStartSlot, { shaderBindings.srv.data(), shaderBindings.srvCount });
	}

	// Set samplers	// Set samplers
	if (shaderBindings.samplerCount > 0) {
		cmdBuffer->setPSSamplers(shaderBindings.samplerStartSlot, { shaderBindings.samplers.data(), shaderBindings.samplerCount });
	}

	// Set constants
	if (bindPoints[0] != invalidBindPoint) {
		const CBAlloc cb { shaderBindings.constantBuffer, shaderBindings.firstConstant, shaderBindings.numConstants };
		cmdBuffer->setVSConstantBuffers(bindPoints[0], { cb });
		cmdBuffer->setPSConstantBuffers(bindPoints[0], { cb });
	}

	return bindPoints[1]; // for mesh
}

void setModel(CommandBuffer* cmdBuffer, const Model& model, uint slot, bool useShadowIndexBuffer) {
	cmdBuffer->setVSRawConstantBuffers(slot, { model.constantBuffer });
	cmdBuffer->setVertexBuffer(model.geometryBuffer, sizeof(GPUVertex), 0, 0);
	cmdBuffer->setIndexBuffer(model.geometryBuffer,
	                          IndexFormat::index16,
	                          useShadowIndexBuffer ? model.shadowIndexBufferOffset : model.indexBufferOffset);
}

std::pair<CBAlloc, int> uploadSortedInstances(GPUAllocator& gpuAllocator, const ModelInstance* instances, const uint64* keys, int count) {
	ZoneScoped;

	struct alignas(16) InstanceData {
		HLSL_float3 position;
		HLSL_float  scale;
		HLSL_float4 orientation;
		HLSL_float3 prevPosition;
		HLSL_float  ID;
		HLSL_float4 prevOrientation;
	};

	count = gpuAllocator.getAvailableCount(count, sizeof(InstanceData));
	if (! count) {
		return {};
	}

	auto [constBlock, mappedData] = gpuAllocator.map<InstanceData>(count);
	for (int i = 0; i < count; ++i) {
		const ModelInstance& instance = instances[keys[i] & 0xFFFF];
		mappedData->position = instance.position;
		mappedData->scale = instance.scale;
		mappedData->orientation = instance.orientation;
		mappedData->prevPosition = instance.prevPosition;
		mappedData->ID = instance.id;
		mappedData->prevOrientation = instance.prevOrientation;
		++mappedData;
	}
	gpuAllocator.unmap(constBlock);

	return { constBlock, count };
}

} // namespace

struct ModelRenderer::PerSceneData {
	const ModelInstance* instances;
	int                  instanceCount;
	CBAlloc*             CBs;
	uint8_t*             uploadedBits;
	float                simTime;
};

ModelRenderSettings::ModelRenderSettings()
    : wireframe { false }
    , lodEnabled { true }
    , lodThreshold { 0.000125f }
    , lodBias { 0 }
    , drawBoundingBoxesEnabled { false }
    , drawBoundingSpheresEnabled { false } {
}

void ModelRenderSettings::setWireframe(bool enabled) {
	wireframe = enabled;
}

bool ModelRenderSettings::getWireframe() const {
	return wireframe;
}

void ModelRenderSettings::setLODEnabled(bool enabled) {
	lodEnabled = enabled;
}

bool ModelRenderSettings::getLODEnabled() const {
	return lodEnabled;
}

void ModelRenderSettings::setLODThreshold(float value) {
	lodThreshold = std::max(0.f, value);
}

float ModelRenderSettings::getLODThreshold() const {
	return lodThreshold;
}

void ModelRenderSettings::setLODBias(int value) {
	lodBias = value;
}

int ModelRenderSettings::getLODBias() const {
	return lodBias;
}

void ModelRenderSettings::setDrawBoundingBoxes(bool enabled) {
	drawBoundingBoxesEnabled = enabled;
}

bool ModelRenderSettings::getDrawBoundingBoxes() const {
	return drawBoundingBoxesEnabled;
}

bool ModelRenderSettings::getDrawBoundingSpheres() const {
	return drawBoundingSpheresEnabled;
}

void ModelRenderSettings::setDrawBoundingSpheres(bool enabled) {
	drawBoundingSpheresEnabled = enabled;
}

ModelRenderer::ModelRenderer(const ModelManager& modelManager, const MaterialManager& materialManager)
    : modelManager { modelManager }
    , materialManager { materialManager } {
}

RenderSettings ModelRenderer::getSettings() {
	return { "Models", &settings, getTypeId(&settings) };
}

void ModelRenderer::initializeShaders(const ShaderManager& shaderManager) {
	nullShader = shaderManager.findCompiledShaderByName("modelNullShader");
}

void ModelRenderer::declareResources(PipelineSetup& pipelineSetup) {
	allModelsId = pipelineSetup.declareData<PerSceneData>("models");
	opaqueModelsId = pipelineSetup.declareData<InstanceSpan>("opaqueModels");
	transparentModelsId = pipelineSetup.declareData<InstanceSpan>("transparentModels");
}

void ModelRenderer::setupPipeline(PipelineSetup& pipelineSetup) {
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "GBuffer");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&gBufferPass);
		gBufferPass.modelsId = passInfo.bindData("opaqueModels");
		gBufferPass.viewType = ViewType::main;
		gBufferPass.shaderVariant = ShaderVariant::gbuffer;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Transparencies");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&transparentPass);
		transparentPass.modelsId = passInfo.bindData("transparentModels");
		transparentPass.viewType = ViewType::main;
		transparentPass.shaderVariant = ShaderVariant::transparent;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Cascaded shadowMap");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&dirShadowPass);
		dirShadowPass.modelsId = passInfo.bindData("opaqueModels");
		dirShadowPass.viewType = ViewType::dirShadows;
		dirShadowPass.shaderVariant = ShaderVariant::shadow;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Point lights shadows");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&pointShadowPass);
		pointShadowPass.modelsId = passInfo.bindData("opaqueModels");
		pointShadowPass.viewType = ViewType::pointShadows;
		pointShadowPass.shaderVariant = ShaderVariant::shadow;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Spot lights shadows");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&spotShadowPass);
		spotShadowPass.modelsId = passInfo.bindData("opaqueModels");
		spotShadowPass.viewType = ViewType::spotShadows;
		spotShadowPass.shaderVariant = ShaderVariant::shadow;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Water reflections");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&waterReflectionPass);
		waterReflectionPass.modelsId = passInfo.bindData("opaqueModels");
		waterReflectionPass.viewType = ViewType::reflections;
		waterReflectionPass.shaderVariant = ShaderVariant::reflection;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Underwater reflections");
		passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&uwReflectionPass);
		uwReflectionPass.modelsId = passInfo.bindData("opaqueModels");
		uwReflectionPass.viewType = ViewType::uwReflections;
		uwReflectionPass.shaderVariant = ShaderVariant::reflection;
	}
	{
		auto passInfo = pipelineSetup.createChildPass("Models", "Debug");
		// passInfo.setEntryPoint([this](auto&&... args) { renderModels(args...); });
		passInfo.setUserData(&debugPass);
		debugPass.drawUtilsId = passInfo.bindData("drawUtils");
		debugPass.opaqueModelsId = passInfo.bindData("opaqueModels");
		debugPass.transparentModelsId = passInfo.bindData("transparentModels");
	}
	pipelineSetup.registerCPUJob([this](auto&&... args) { cullAndUploadModels(args...); });
}

void ModelRenderer::onDeviceCreated(Device& device) {
	static const VertexElement decl[] = {
		{ 0, ElementFormat::USHORT4N, ElementUsage::position, InputClass::vertexData },
		{ 0, ElementFormat::USHORT2N, ElementUsage::normal, InputClass::vertexData },
		{ 0, ElementFormat::FLOAT16_2, ElementUsage::texCoord, InputClass::vertexData },
		{ 1, ElementFormat::UINT32, ElementUsage::blendIndices, InputClass::instanceData },
	};
	inputLayout = device.createInputLayout(decl, nullShader->getSignature());
}

void ModelRenderer::debug(DrawUtilities& drawUtils, const RenderView& view) const {
	if (! settings.getDrawBoundingBoxes() && ! settings.getDrawBoundingSpheres()) {
		return;
	}
	const SimdVector color = SimdVector::GetConstant<SimdConstant::_1>();
	const auto       modelSystem = view.scene->querySystem<ModelSystem>();
	const Position   worldOrigin = view.camera.worldOrigin;
	for (const auto& instance : modelSystem->getInstances()) {
		const Model& model = modelManager.getModelUnchecked(instance.modelId);
		const uint32 lodIndex = model.surfaces[instance.surfaceIndex].startMeshIndex;
		const Mesh&  mesh = model.meshes[lodIndex];

		if (settings.getDrawBoundingBoxes()) {
			SimdVector bboxCenter;
			bboxCenter.Load(mesh.bboxCenter);
			SimdVector bboxDiag;
			bboxDiag.Load(mesh.bboxDiag);
			SimdScalar scale { instance.scale };
			drawUtils.drawOrientedBox(worldOrigin + instance.position, bboxCenter * scale, bboxDiag * scale, instance.orientation, color);
		}
		if (settings.getDrawBoundingSpheres()) {
			SimdVector bsphere;
			bsphere.Load(mesh.bsphere);
			bsphere *= SimdScalar { instance.scale };
			SimdVector sphereCenter = instance.position + rotate(instance.orientation, bsphere);
			float      radius = bsphere.GetComponent<3>().getFloat();
			drawUtils.drawSphere(worldOrigin + sphereCenter, radius, color);
		}
	}
}

void ModelRenderer::cullAndUploadModels(PipelineRuntime& pipeline, Device& device) const {
	constexpr uint32 supportedViews = makeViewTypeMask<ViewType::main,
	                                                   ViewType::dirShadows,
	                                                   ViewType::pointShadows,
	                                                   ViewType::spotShadows,
	                                                   ViewType::reflections,
	                                                   ViewType::uwReflections>();
	for (const RenderView& view : pipeline.getAllViews()) {
		if (view.getTypeMask() & supportedViews) {
			uploadModelsForView(view, device, pipeline);
		}
	}
}

void ModelRenderer::uploadModelsForView(const RenderView& view, Device& device, PipelineRuntime& pipeline) const {
	LinearAllocator& scratchAllocator = getGlobalScratchAllocator(); // FIXME not thread safe. Let pipeline pass it to job
	LinearAllocator& frameAllocator = pipeline.getFrameAllocator();

	const MemoryScope memoryScope { scratchAllocator };

	float lodThresholdMul = 1.f;
	if (view.type != ViewType::main) {
		lodThresholdMul = 2.f; // use lower res models
	}

	PerSceneData sceneData = pipeline.getData<PerSceneData>(allModelsId, view.sceneDataBucket, {});
	if (! sceneData.instances) {
		const auto modelSystem = view.scene->querySystem<ModelSystem>();
		const auto instances = modelSystem->getInstances();
		sceneData.instances = instances.data();
		sceneData.instanceCount = (int)instances.size();
		sceneData.CBs = frameAllocator.allocArray<CBAlloc>(instances.size());
		sceneData.uploadedBits = frameAllocator.allocArray<uint8_t>((instances.size() + 7) / 8);
		sceneData.simTime = modelSystem->getSimTime();

		// views with the same scene share GPU data uploaded per curve
		std::memset(sceneData.uploadedBits, 0, sizeof(uint8_t) * ((instances.size() + 7) / 8));
#ifdef _DEBUG
		std::memset(sceneData.CBs, 0, sizeof(CBAlloc) * instances.size());
#endif

		pipeline.setData(allModelsId, sceneData, view.sceneDataBucket);
	}
	// else view shares scene with other views

	uint32_t* const visibleIndices = scratchAllocator.allocArray<uint32_t>(sceneData.instanceCount);
	uint16*         meshIndices = scratchAllocator.allocArray<uint16>(sceneData.instanceCount);
	const int       numVisible = cullModels(visibleIndices,
                                      meshIndices,
                                      sceneData.instances,
                                      sceneData.instanceCount,
                                      view,
                                      modelManager,
                                      materialManager,
                                      settings.getLODEnabled() ? settings.getLODThreshold() * lodThresholdMul : 0.f,
                                      settings.getLODBias());
	if (numVisible == 0) {
		return;
	}

	// Sort visible instances by shading, material, model and mesh
	uint64*    sortKeys = frameAllocator.allocArray<uint64>(numVisible); // scratchAllocator.allocArray<uint64>(numVisible);
	MaterialId currMaterialId;
	uint64     materialKey = 0;
	uint64     shadingKey = 0;
	for (int i = 0; i < numVisible; ++i) {
		const uint32         index = visibleIndices[i];
		const ModelInstance& instance = sceneData.instances[index];
		const uint64         modelKey = instance.modelId.getValue();
		const uint64         meshIndex = meshIndices[i];
		assert(meshIndex < (1u << 10u));

		if (instance.materialId != currMaterialId) {
			currMaterialId = instance.materialId;
			const Material& material = materialManager.getRuntimeUnchecked(currMaterialId);
			materialKey = (uint64)(instance.materialId.getValue() & 0xFFFF) << 52u;
			shadingKey = ((uint64)material.shading << 63u);
		}

		sortKeys[i] = shadingKey | materialKey | (modelKey << 42) | (meshIndex << 32) | index;
	}
	std::sort(sortKeys, sortKeys + numVisible);

	// Partition visible instances into opaque and transparent spans
	size_t  opaqueCount = 0;
	size_t  transparentCount = 0;
	uint64* opaque = frameAllocator.allocArray<uint64>(sceneData.instanceCount);
	uint64* transparent = frameAllocator.allocArray<uint64>(sceneData.instanceCount);
	for (int i = 0; i < numVisible; ++i) {
		if (0 == (sortKeys[i] >> 63u)) { // test opaque bit
			opaque[opaqueCount++] = sortKeys[i];
		}
		else {
			transparent[transparentCount++] = sortKeys[i];
		}
	}
	pipeline.setData(opaqueModelsId, InstanceSpan { opaque, opaqueCount }, view.dataBucket);
	pipeline.setData(transparentModelsId, InstanceSpan { transparent, transparentCount }, view.dataBucket);
}

void ModelRenderer::renderModels(const Pass& pass, RenderQueue& commandQueue, const PipelineRuntime& pipeline, Device& device) const {
	const auto passData = static_cast<const ModelRenderPass*>(pass.userData);
	for (const RenderView& view : pipeline.getViews(passData->viewType)) {
		renderView(view, pass, commandQueue, device, passData->shaderVariant, pipeline, passData->modelsId);
	}
}

void ModelRenderer::renderView(const RenderView& view, const Pass& pass, RenderQueue& commandQueue, Device& device,
                               ShaderVariant shaderVariant, const PipelineRuntime& pipeline, DataBlobId visibleModelsId) const {
	GPUAllocator& gpuAllocator = device.GetAllocator();

	const bool useShadowIndexBuffer = false; // TODO Need to read the vertex shader inputs to determine

	const PerSceneData   sceneData = pipeline.getData<PerSceneData>(allModelsId, view.sceneDataBucket, {});
	const ModelInstance* instances = sceneData.instances;
	const InstanceSpan   visibleInstances = pipeline.getData<InstanceSpan>(visibleModelsId, view.dataBucket, {});
	if (visibleInstances.empty()) {
		return;
	}

	// Create command buffers
	CommandBuffer* cmdBuffer = device.getTemporaryCommandBuffer(CommandBufferFamily::direct);
	beginView(*cmdBuffer, sceneData.simTime, device);

	uint            currMeshSlot = 0;
	MaterialId      currMaterialId;
	ModelResourceId currModelId;
	const Model*    currModel = nullptr;

	int uploadOffset = 0;
	do {
		const auto [instanceCB, partialCount] = uploadSortedInstances(gpuAllocator,
		                                                              instances,
		                                                              visibleInstances.data() + uploadOffset,
		                                                              (int)visibleInstances.size() - uploadOffset);
		if (! partialCount) {
			LogError("Failed to upload some model instances");
			break;
		}

		cmdBuffer->setVSConstantBuffers(3, { instanceCB });
		cmdBuffer->setPSConstantBuffers(3, { instanceCB });

		int startInstanceLocation = 0;

		for (int i = 0; i < partialCount; ++i) {
			const uint64         sortKey = visibleInstances[i + uploadOffset];
			const ModelInstance& instance = instances[sortKey & 0xFFFF];

			// Set material
			if (instance.materialId != currMaterialId) {
				currMaterialId = instance.materialId;
				const Material& material = materialManager.getRuntime(currMaterialId);
				currMeshSlot = setMaterial(cmdBuffer, material, (int)shaderVariant);
			}
			// Set model
			if (instance.modelId != currModelId) {
				currModelId = instance.modelId;
				currModel = &modelManager.getModelUnchecked(currModelId); // TODO support null model
				setModel(cmdBuffer, *currModel, currMeshSlot, useShadowIndexBuffer);
			}

			// Draw all instances having the same material and mesh
			if ((i + 1) == partialCount || ((visibleInstances[i + uploadOffset] >> 32) != (visibleInstances[i + uploadOffset + 1] >> 32))) {
				const uint32 meshIndex = (visibleInstances[i + uploadOffset] >> 32) & 0x3FF;
				const Mesh&  mesh = currModel->meshes[meshIndex];
				cmdBuffer->drawIndexedInstanced(mesh.indexCount,
				                                i + 1 - startInstanceLocation,
				                                mesh.startIndex,
				                                mesh.baseVertex,
				                                startInstanceLocation);
				startInstanceLocation = i + 1;
			}
		}

		uploadOffset += partialCount;
	} while (uploadOffset < visibleInstances.size());
	cmdBuffer->endEvent();
	commandQueue.addCommandBuffer(cmdBuffer, pass.gpuSubmitOrder, view.subIndex);
}

void ModelRenderer::beginView(CommandBuffer& cmdBuffer, float simTime, Device& device) const {
	HLSL_struct ViewConstants {
		HLSL_float2 pixelSize; // for refractions
		HLSL_float  simTime;
	};
	const ViewConstants viewConst = {
		// FIXME In a global CB
		{ 1.f / device.getBackBufferWidth(), 1.f / device.getBackBufferHeight() },
		simTime,
	};

	const CBAlloc cb = device.GetAllocator().upload(viewConst);

	cmdBuffer.beginEvent("Models");
	cmdBuffer.setInputLayout(inputLayout);
	cmdBuffer.setVSConstantBuffers(2, { cb });
	cmdBuffer.setPSConstantBuffers(2, { cb });
	cmdBuffer.setPrimitiveTopology(PrimitiveType::TriangleList);
	if (settings.getWireframe()) {
		cmdBuffer.setRasterizerState(DefStates::wireframeCcw);
	}
	cmdBuffer.setVertexBuffer(device.getInstanceBuffer(), sizeof(uint32), 1, 0);
}

} // namespace Typhoon
